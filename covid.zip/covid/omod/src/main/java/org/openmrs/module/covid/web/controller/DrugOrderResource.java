package org.openmrs.module.covid.web.controller;

import org.openmrs.module.covid.DrugOrderBL;

/**
 *
 * @author barrylevine
 */
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.api.DrugOrderBLService;

import org.openmrs.module.webservices.rest.web.RequestContext;
import org.openmrs.module.webservices.rest.web.RestConstants;
import org.openmrs.module.webservices.rest.web.annotation.PropertyGetter;
import org.openmrs.module.webservices.rest.web.annotation.Resource;
import org.openmrs.module.webservices.rest.web.representation.DefaultRepresentation;
import org.openmrs.module.webservices.rest.web.representation.FullRepresentation;
import org.openmrs.module.webservices.rest.web.representation.Representation;
import org.openmrs.module.webservices.rest.web.response.ResponseException;
import org.openmrs.module.webservices.rest.web.resource.impl.DataDelegatingCrudResource;
import org.openmrs.module.webservices.rest.web.resource.impl.DelegatingResourceDescription;
import org.openmrs.module.webservices.rest.web.resource.impl.NeedsPaging;

@Resource(name = RestConstants.VERSION_1 + "/drugorderbl", supportedClass = DrugOrderBL.class, supportedOpenmrsVersions = {
        "2.0.*", "2.1.*", "2.2.*", "2.3.*", "2.4.*" })
public class DrugOrderResource extends DataDelegatingCrudResource<DrugOrderBL> {
	
	/*
	curl -u admin:Admin123 -X GET "http://localhost:8081/openmrs/ws/rest/v1/drugorderbl"  -H  "accept: application/json"

	*/
	public NeedsPaging<DrugOrderBL> doGetAll(RequestContext context) {
		System.out.println("****************doGetAll: " + context);
		return new NeedsPaging<DrugOrderBL>(Context.getService(DrugOrderBLService.class).getAllDrugOrders(), context);
		
	}
	
	@Override
	public DrugOrderBL getByUniqueId(String string) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
	@Override
	protected void delete(DrugOrderBL t, String string, RequestContext rc) throws ResponseException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
	@Override
	public void purge(DrugOrderBL t, RequestContext rc) throws ResponseException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
	@Override
	public DelegatingResourceDescription getRepresentationDescription(Representation r) {
		if (r instanceof DefaultRepresentation) {
			DelegatingResourceDescription description = new DelegatingResourceDescription();
			description.addProperty("drugId");
			description.addProperty("patientId");
			description.addLink("full", ".?v=" + RestConstants.REPRESENTATION_FULL);
			description.addSelfLink();
			return description;
		} else if (r instanceof FullRepresentation) {
			DelegatingResourceDescription description = new DelegatingResourceDescription();
			description.addProperty("drugId");
			description.addProperty("patientId");
			description.addSelfLink();
			return description;
		}
		return null;
	}
	
	public DrugOrderBL newDelegate() {
		System.out.println("****************newDelegate: ");
		return new DrugOrderBL();
	}
	
	@PropertyGetter("display")
	public String getDisplayString(DrugOrderBL order) {
		return "DrugID: " + order.getDrugId() + "/" + "PatientID: " + order.getPatientId();
	}
	
	@Override
	public DrugOrderBL save(DrugOrderBL t) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
}
