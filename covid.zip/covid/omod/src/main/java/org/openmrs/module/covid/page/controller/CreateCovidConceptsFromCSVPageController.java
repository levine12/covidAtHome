/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid.page.controller;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.openmrs.Concept;
import org.openmrs.ConceptName;
import org.openmrs.ConceptReferenceTerm;
import org.openmrs.ConceptSource;
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.web.controller.UploadControllerCovidModule;

import org.openmrs.ui.framework.page.PageModel;
import org.openmrs.ui.framework.page.PageRequest;
import org.openmrs.util.OpenmrsUtil;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author levine
 */
public class CreateCovidConceptsFromCSVPageController {
	
	private final String uuidNumeric = "8d4a4488-c2cc-11de-8d13-0010c6dffd0f";
	
	private final String uuidText = "8d4a4ab4-c2cc-11de-8d13-0010c6dffd0f";
	
	private final String uuidBoolean = "8d4a5cca-c2cc-11de-8d13-0010c6dffd0f";
	
	private final String uuidClassTest = "8d4907b2-c2cc-11de-8d13-0010c6dffd0f";
	
	private final String uuidClassFinding = "8d491a9a-c2cc-11de-8d13-0010c6dffd0f";
	
	private String uuidClassQuestion = "8d491e50-c2cc-11de-8d13-0010c6dffd0f";
	
	RestPostGet restCall = new RestPostGet();
	
	String baseURL;
	
	private ConceptInfo conceptInfo;
	
	public void controller(HttpServletRequest request, PageModel pageModel, PageRequest pageRequest) {
		String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + "/" + UploadControllerCovidModule.covidFolder;
		ArrayList<String> results = new ArrayList<String>();
		File folder = new File(folderLocation);
		File[] files = folder.listFiles();
		
		//If this pathname does not denote a directory, then listFiles() returns null.
		if (files != null) {
			for (File file : files) {
				if (!file.isFile()) {
					continue;
				}
				String fileName = file.getName().toLowerCase();
				if (!file.getName().startsWith(".") && file.getName().contains("concept")) {
					results.add(file.getName());
				}
			}
		}
		results.add("NEWaa");
		
		String urlPathToPage = (request.getRequestURL().toString()).trim();
		urlPathToPage = urlPathToPage.substring(0, urlPathToPage.lastIndexOf("/") + 1);
		pageModel.addAttribute("files", results);
		pageModel.addAttribute("url", urlPathToPage);
		/*
		SimpleObject user = new SimpleObject();
		user.add("username", "testuser");
		user.add("password", "Secret123");
		user.add("person", "da7f524f-27ce-4bb2-86d6-6d1d05312bd5");
		
		try {
		String json = new ObjectMapper().writeValueAsString(user);
		System.out.println("\n\njson: " + json);
		//createCodedConcept(request);
		}
		catch (IOException ex) {
		Logger.getLogger(CreateConceptsAndDrugsFromCSVPageController.class.getName()).log(Level.SEVERE, null, ex);
		}
		 */
	}
	
	private void createCodedConcept(HttpServletRequest request) {
		String action = "{\"names\": [{\"name\": \"myconcept7\",\"locale\": \"en\",\"localePreferred\": true,\"conceptNameType\": \"FULLY_SPECIFIED\"}],"
		        + "\"datatype\": \"8d4a48b6-c2cc-11de-8d13-0010c6dffd0f\","
		        + "\"version\": \"1.0\","
		        + "\"answers\": [ \"1066AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\",\"1065AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\" ],"
		        + "\"conceptClass\": \"8d4918b0-c2cc-11de-8d13-0010c6dffd0f\" }";
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		String baseUrl1 = url.substring(0, contextPathIndex) + contextPath;
		String baseURL = baseUrl1 + "/ws/rest/v1/";
		
		String jsonResponse = restCall.doPostRestCall(baseURL + "concept", action);
		System.out.println("\n\n\ncreateCodedConceptFromCSVPageController\n" + jsonResponse);
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonResponse);
		JsonObject obj = jsEl.getAsJsonObject();
		String conceptUUID = obj.get("uuid").getAsString();
		System.out.println("\n\nCONCEPT UUID: " + conceptUUID);
	}
	
	public String post(HttpSession session, HttpServletRequest request,
	        @RequestParam(value = "covidConceptsCsvFile", required = false) String covidConceptsCsvFile) {
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		String baseURL = url.substring(0, contextPathIndex) + contextPath;
		baseURL = baseURL + "/ws/rest/v1/";
		System.out.println("\n\n\n*********************************************************************"
		        + "POST ------------ CreateConceptsFromCSVPageController: " + covidConceptsCsvFile + "\n\n" + baseURL);
		
		/*
		IF CONCEPT IS ALREADY IN ENGLISH BUT NOT ARMENIAN THEN DO THE FOLLOWING:
		ADD TO LOCALE: hy
		THEN USE THE FOLLOWING TO ADD THE NEW NAME:
		curl -u admin:Admin123  -X POST "http://localhost:8080/openmrs/ws/rest/v1/concept/ddaa091d-fb1e-4164-964c-9f4a8dfc2802/name" -H  "accept: application/json" -H  "content-type: application/json" -d "{\"name\": \"armenianName\",    \"locale\": \"hy\"}"
		USE THE FOLLOWING TO GET ALL NAMES FOR A CONCEPT
		curl -u admin:Admin123  -X GET "http://localhost:8080/openmrs/ws/rest/v1/concept/ddaa091d-fb1e-4164-964c-9f4a8dfc2802/name" -H  "accept: application/json" 
		 */
		//createParentAndRelationship();
		try {
			String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + "/"
			        + UploadControllerCovidModule.covidFolder;
			File folder = new File(folderLocation);
			File file = new File(folder, covidConceptsCsvFile);
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
			//System.out.println("\n\nHERE\n\n");
			String nextLine;
			while (((nextLine = in.readLine()) != null) && (!nextLine.replace(",", "").equals(""))) {
				System.out.println("\n\nADDING: " + nextLine + "\n\n");
				ConceptInfo conceptInfo = new ConceptInfo(nextLine.trim(), restCall, baseURL);
				Concept concept = Context.getConceptService().getConceptByName(conceptInfo.getNameEnglish());
				System.out.println(conceptInfo + "\nCONCEPT: " + concept);
				if (concept == null) {
					createConcept(request, conceptInfo);
					continue;
				}
				//updateArmenianIfNecessary(request, concept, conceptInfo);
			}
			in.close();
		}
		catch (Exception e) {
			System.out.println("POST: " + e);
		}
		return "redirect:" + "covid/createCovidConceptsFromCSV.page";
	}
	
	private void updateArmenianIfNecessary(HttpServletRequest request, Concept concept, ConceptInfo conceptInfo) {
		System.out.println("\n\nupdateArmenianIfNecessary\n");
		Locale loc;
		ConceptName cn;
		Set<Locale> locales = concept.getAllConceptNameLocales();
		System.out.println("\n\n\nLOCALES\n" + locales);
		for (Locale locale : locales) {
			if (locale.toString().equals("hy")) {
				return;
			}
			//System.out.println("LOCALE: " + locale.toString() + " " + locale.toString().equals("hy"));
		}
		if (conceptInfo.getNameArmenian() == null) {
			return;
		}
		RestPostGet restCall = new RestPostGet();
		System.out.println("\n\nCREATING Armenian CONCEPT name\n\n");
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		String baseUrl = url.substring(0, contextPathIndex) + contextPath;
		baseUrl += "/ws/rest/v1/concept/" + concept.getUuid() + "/name";
		
		System.out.println("\n\nbaseUrl " + baseUrl);
		String action = "{\"name\": \"ARMENIANNAME\",    \"locale\": \"hy\"}";
		action = action.replace("ARMENIANNAME", conceptInfo.getNameArmenian());
		String jsonResponse = restCall.doPostRestCall(baseUrl, action);
		return;
	}
	
	private void createConcept(HttpServletRequest request, ConceptInfo conceptInfo) {
		RestPostGet restCall = new RestPostGet();
		System.out.println("\n\nCREATING CONCEPT\n\n");
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		String baseUrl1 = url.substring(0, contextPathIndex) + contextPath;
		String baseURL = baseUrl1 + "/ws/rest/v1/";
		/*
		String action = "{  \"names\": [    {      \"name\": \"test concept55\",      \"locale\": \"en\",      "
		        + "\"localePreferred\": true,      \"conceptNameType\": \"FULLY_SPECIFIED\"    },"
		        + "{      \"name\": \"ՏալըՏալըՏալըՏալը\",      \"locale\": \"hy\",      "
		        + "\"localePreferred\": false,      \"conceptNameType\": \"FULLY_SPECIFIED\"    }  ], "
		        //+ "\"datatype\": \"8d4a4c94-c2cc-11de-8d13-0010c6dffd0f\", \"version\": \"1.0\",  "
		        + "\"datatype\": \"8d4a4488-c2cc-11de-8d13-0010c6dffd0f\", \"version\": \"1.0\",  "
		        + "\"conceptClass\": \"Diagnosis\", \"descriptions\": [   {\"description\": \"barry desc\", \"locale\": \"en\" } ],"
		        + "\"mappings\": [{\"conceptReferenceTerm\":\"" + "6d659abe-5821-316b-87cb-71412cc30ce7"
		        + "\",\"conceptMapType\":\"" + "35543629-7d8c-11e1-909d-c80aa9edcf4e" + "\"}],"
		        + "\"hiAbsolute\": 250,\"lowAbsolute\": 0,\"units\": \"kg\",\"allowDecimal\": true}";
		 */
		System.out.println("*****************************CHECKING CONCEPT: " + conceptInfo.getNameEnglish());
		Concept concept = Context.getConceptService().getConceptByName(conceptInfo.getNameEnglish());
		System.out.println("CONCEPT: " + concept);
		if (concept != null) {
			System.out.println("\n\n\nCONCEPT ALREADY CREATED: " + conceptInfo.getNameEnglish() + "\n\n");
			return;
		}
		String action = getRESTAction(conceptInfo);
		System.out.println("\n\nACTION:\n" + action);
		
		String jsonResponse = restCall.doPostRestCall(baseURL + "concept", action);
		System.out.println("\n\n\nCreateConceptsFromCSVPageController\n" + jsonResponse);
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonResponse);
		JsonObject obj = jsEl.getAsJsonObject();
		String conceptUUID = obj.get("uuid").getAsString();
		System.out.println("\n\nCONCEPT UUID: " + conceptUUID);
		
		//createConceptMapping(restCall, baseURL, conceptUUID);
	}
	
	private String getRESTAction(ConceptInfo conceptInfo) {
		System.out.println("getRESTAction " + conceptInfo);
		String action;
		if (conceptInfo.getNameArmenian() != null) {
			action = "{  \"names\": [    {      \"name\": \"CONCEPTNAMEENGLISH\",      \"locale\": \"en\",      "
			        + "\"localePreferred\": true,      \"conceptNameType\": \"FULLY_SPECIFIED\"    },"
			        + "{      \"name\": \"CONCEPTNAMEARMENIAN\",      \"locale\": \"hy\",      "
			        + "\"localePreferred\": false,      \"conceptNameType\": \"FULLY_SPECIFIED\"    }  ], "
			        //+ "\"datatype\": \"DATATYPE\", \"version\": \"1.0\",  "
			        + "\"datatype\": \"DATATYPEUUID\", \"version\": \"1.0\",  "
			        + "\"conceptClass\": \"CONCEPTCLASSUUID\", \"descriptions\": [   {\"description\": \"DESCRIPTION\", \"locale\": \"en\" } ],"
			        + "ANSWERS" + "\"mappings\": [{\"conceptReferenceTerm\":\"" + "CONCEPTREFERENCETERMUUID"
			        + "\",\"conceptMapType\":\"" + "35543629-7d8c-11e1-909d-c80aa9edcf4e" + "\"}]}";
			action = action.replace("CONCEPTNAMEENGLISH", conceptInfo.getNameEnglish());
			action = action.replace("CONCEPTNAMEARMENIAN", conceptInfo.getNameArmenian());
			action = action.replace("DATATYPEUUID", conceptInfo.getDatatypeUUID());
			action = action.replace("DESCRIPTION", conceptInfo.getDescription());
			action = action.replace("CONCEPTCLASSUUID", conceptInfo.getClassUUID());
			action = action.replace("CONCEPTREFERENCETERMUUID", conceptInfo.getConceptReferenceTermUUID());
		} else {
			action = "{  \"names\": [    {      \"name\": \"CONCEPTNAMEENGLISH\",      \"locale\": \"en\",      "
			        + "\"localePreferred\": true,      \"conceptNameType\": \"FULLY_SPECIFIED\"    }], "
			        + "\"datatype\": \"DATATYPEUUID\", \"version\": \"1.0\",  "
			        + "ANSWERS"
			        + "\"conceptClass\": \"CONCEPTCLASSUUID\", \"descriptions\": [   {\"description\": \"DESCRIPTION\", \"locale\": \"en\" } ]}";
			action = action.replace("CONCEPTNAMEENGLISH", conceptInfo.getNameEnglish());
			action = action.replace("DATATYPEUUID", conceptInfo.getDatatypeUUID());
			action = action.replace("DESCRIPTION", conceptInfo.getDescription());
			action = action.replace("CONCEPTCLASSUUID", conceptInfo.getClassUUID());
		}
		if (conceptInfo.getAnswerUUIDsForCodedConcepts() == null) {
			action = action.replace("ANSWERS", "");
		} else {
			action = action.replace("ANSWERS", getAnswerUUIDsForAction(conceptInfo));
		}
		return action;
	}
	
	String getAnswerUUIDsForAction(ConceptInfo conceptInfo) {
		String answers; //"\"answers\": [ \"1066AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\",\"1065AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\" ],";
		ArrayList<String> answerUUIDsForCodedConcepts = conceptInfo.getAnswerUUIDsForCodedConcepts();
		String answerUUIDs = "";
		for (String answerUUID : answerUUIDsForCodedConcepts) {
			if (!answerUUIDs.equals("")) {
				answerUUIDs += ",";
			}
			answerUUIDs += "\"" + answerUUID + "\"";
		}
		answers = "\"answers\": [" + answerUUIDs + "],";
		return answers;
	}
	
}

class ConceptInfo {
	
	private int englishNameColumn = 0;
	
	private int armenianNameColumn = 1;
	
	private int descriptionColumn = 2;
	
	private int conceptClassNameColumn = 3;
	
	private int datatypeColumn = 4;
	
	private int snomedCodeColumn = 5;
	
	private int codedConceptStartColumn = 6;
	
	String nameEnglish, nameArmenian, description, classUUID, datatypeUUID, conceptReferenceTermUUID;
	
	ArrayList<String> answerUUIDsForCodedConcepts;
	
	int snomedId;
	
	RestPostGet restCall;
	
	String baseURL;
	
	ConceptInfo(String csvLine, RestPostGet restCall, String baseURL) {
		System.out.println("\n\nLINE: " + csvLine + "\n\n");
		this.restCall = restCall;
		this.baseURL = baseURL;
		//String[] lineData = csvLine.split(",");
		String[] lineData = splitNextLine(csvLine);
		nameEnglish = lineData[englishNameColumn].trim();
		nameEnglish = removeBadChars(nameEnglish);
		System.out.println("\nlineData.length: " + lineData.length);
		for (int i = 0; i < lineData.length; i++) {
			System.out.println(i + " " + lineData[i]);
		}
		if (lineData[armenianNameColumn].trim().equals("")) { // No Armenian concept name and no snomed mapping
			nameArmenian = null;
			snomedId = 0;
			
		} else {
			nameArmenian = lineData[armenianNameColumn];
			// below needs fixing since can have coded concepts where linelength > 5
			
			if (lineData.length > 5) {
				if (!lineData[snomedCodeColumn].trim().equals("")) {
					snomedId = Integer.valueOf(lineData[snomedCodeColumn]);
				}
			}
		}
		description = lineData[descriptionColumn].trim();
		String className = lineData[conceptClassNameColumn].trim();
		className = removeBadChars(className);
		String dataType = lineData[datatypeColumn].trim();
		dataType = removeBadChars(dataType);
		//System.out.println("\n\nCONCEPT INFO, NAME ARM, SNOWMED ID: " + nameArmenian + " , " + snomedId);
		classUUID = Context.getConceptService().getConceptClassByName(className).getUuid();
		datatypeUUID = Context.getConceptService().getConceptDatatypeByName(dataType).getUuid();
		if (!lineData[1].trim().equals("")) {
			//createConceptReferenceTerm();
		}
		nameEnglish = nameEnglish.replaceAll("[\\p{C}]", ""); // remove non-printing characters
		
		if (dataType.equals("Coded")) {
			answerUUIDsForCodedConcepts = mapNamesToUUIDsForCodedConcepts(lineData);
		}
		/*
		System.out.println("\n\nNEW nameEnglishbv FOR: " + nameEnglish);
		byte[] bytes = nameEnglish.getBytes();
		for (int i = 0; i < bytes.length; i++) {
		System.out.println(bytes[i]);
		}
		 */
	}
	
	private String[] splitNextLine(String nextLine) {
		boolean lookforquote = false; // quotes might be included to shield commas within
		String newString = "";
		for (int i = 0; i < nextLine.length(); i++) {
			switch (nextLine.charAt(i)) {
				case ',':
					if (lookforquote) {
						newString += ",";
					} else {
						newString += "^";
					}
					;
					break;
				case '"': {
					if (lookforquote) {
						lookforquote = false;
					} else {
						lookforquote = true;
					}
				}
					break;
				default:
					newString += nextLine.charAt(i);
			}
		}
		String[] items = newString.split("\\^");
		return items;
	}
	
	public ArrayList<String> getAnswerUUIDsForCodedConcepts() {
		return answerUUIDsForCodedConcepts;
	}
	
	private ArrayList<String> mapNamesToUUIDsForCodedConcepts(String[] lineData) {
		ArrayList<String> answerUUIDForCodedConcepts = new ArrayList<String>();
		String conceptName;
		Concept concept;
		for (int i = codedConceptStartColumn; i < lineData.length; i++) {
			if (lineData[i].trim().equals("")) {
				break;
			}
			conceptName = lineData[i].trim();
			if (conceptName.toLowerCase().equalsIgnoreCase("yes")) {
				answerUUIDForCodedConcepts.add("1065AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
				System.out.println("\nConcept Name: " + conceptName + "  UUID: 1065AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
				continue;
			}
			if (conceptName.toLowerCase().equalsIgnoreCase("no")) {
				answerUUIDForCodedConcepts.add("1066AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
				System.out.println("\nConcept Name: " + conceptName + "  UUID: 1066AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
				continue;
			}
			concept = Context.getConceptService().getConceptByName(conceptName);
			if (concept == null) {
				System.out.println("\n\nCOULD NOT FIND CONCEPT: " + conceptName + conceptName.length() + "\n\n");
				continue;
			}
			System.out.println("\nConcept Name: " + conceptName + "  UUID: " + concept.getUuid());
			answerUUIDForCodedConcepts.add(concept.getUuid());
		}
		return answerUUIDForCodedConcepts;
	}
	
	void createConceptReferenceTerm() {
		ConceptSource conceptSource = Context.getConceptService().getConceptSourceByName("SNOMED CT");
		String conceptSourceUUID = conceptSource.getUuid();
		String code = "" + snomedId;
		String uuid;
		ConceptReferenceTerm conceptReferenceTerm = Context.getConceptService().getConceptReferenceTermByCode(code,
		    conceptSource);
		if (conceptReferenceTerm != null) {
			System.out.println("\n\nConceptReferenceTerm already created: " + code + "\n\n");
			uuid = conceptReferenceTerm.getUuid();
			return;
		}
		String action = "{\"code\": \"" + code + "\", \"conceptSource\":\"" + conceptSourceUUID + "\"}";
		System.out.println("createConceptReferenceTerm action: " + action);
		String jsonResponse = restCall.doPostRestCall(baseURL + "conceptreferenceterm", action);
		System.out.println("\n\ncreateConceptReferenceTerm\n" + jsonResponse);
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonResponse);
		uuid = jsEl.getAsJsonObject().get("uuid").getAsString();
		conceptReferenceTermUUID = uuid.trim();
	}
	
	public String getConceptReferenceTermUUID() {
		return conceptReferenceTermUUID;
	}
	
	public void setConceptReferenceTermUUID(String conceptReferenceTermUUID) {
		this.conceptReferenceTermUUID = conceptReferenceTermUUID;
	}
	
	public String getNameEnglish() {
		return nameEnglish;
	}
	
	public void setNameEnglish(String nameEnglish) {
		this.nameEnglish = nameEnglish;
	}
	
	public String getNameArmenian() {
		return nameArmenian;
	}
	
	public void setNameArmenian(String nameArmenian) {
		this.nameArmenian = nameArmenian;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getClassUUID() {
		return classUUID;
	}
	
	public void setClassUUID(String classUUID) {
		this.classUUID = classUUID;
	}
	
	public String getDatatypeUUID() {
		return datatypeUUID;
	}
	
	public void setDatatypeUUID(String datatypeUUID) {
		this.datatypeUUID = datatypeUUID;
	}
	
	public int getSnomedId() {
		return snomedId;
	}
	
	public void setSnomedId(int snomedId) {
		this.snomedId = snomedId;
	}
	
	@Override
	public String toString() {
		return "ConceptInfo{" + "nameEnglish=" + nameEnglish + ", nameArmenian=" + nameArmenian + ", description="
		        + description + ", classUUID=" + classUUID + ", datatypeUUID=" + datatypeUUID + ", snomedId=" + snomedId
		        + '}';
	}
	
	private String removeBadChars(String oldString) {
		oldString = oldString.trim();
		String newString = "";
		for (int i = 0; i < oldString.length(); i++) {
			if (Integer.toHexString(oldString.charAt(i)).length() == 2) {
				newString += oldString.charAt(i);
				continue;
			}
		}
		return newString;
	}
}
