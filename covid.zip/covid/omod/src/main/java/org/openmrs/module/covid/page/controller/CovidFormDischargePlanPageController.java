package org.openmrs.module.covid.page.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.openmrs.ui.framework.page.PageModel;
import org.springframework.web.bind.annotation.RequestParam;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * @author barrylevine
 */
public class CovidFormDischargePlanPageController {
	
	RestPostGet restCall = new RestPostGet();
	
	String restUserName = "restuser";
	
	String restUserPassword = "$kl@*Akjkj3344";
	
	String baseURL, locationUUID, patientUUID, visitTypeUUID, encounterTypeUUID;
	
	public void controller(HttpServletRequest request, PageModel model, HttpSession session) {
		
	}
	
	public String post(HttpSession session, HttpServletRequest request,
	        @RequestParam(value = "patientName", required = false) String patientName) {
		System.out.println("\n\nPOSTING CovidFormPatientScreeningPageController: " + patientName + "\n\n\n");
		
		/*
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonData);
		JsonObject obj = jsEl.getAsJsonObject();
		String conceptUUID = obj.get("display").getAsString();
		System.out.println("\n\nCONCEPT display: " + conceptUUID);
		JsonArray resultArray = obj.getAsJsonArray("vitals");
		for (JsonElement resultElement : resultArray) {
		obj = resultElement.getAsJsonObject();
		obj.entrySet();
		Set<Map.Entry<String, JsonElement>> entries = obj.entrySet();
		for (Map.Entry<String, JsonElement> entry : entries) {
		System.out.println(entry.getKey() + " " + obj.get(entry.getKey()).getAsString());
		}
		//System.out.println("heartRate as int: " + obj.get("heartRate").getAsInt());
		}
		*/
		return "redirect:" + "covid/covidFormDailyHomeHealthNote.page";
	}
}
