package org.openmrs.module.covid.page.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.openmrs.module.covid.web.controller.UploadControllerCovidModule;
import org.openmrs.ui.framework.page.PageModel;
import org.openmrs.util.OpenmrsUtil;

public class UploadCSVFilePageController {
	
	public void controller(HttpServletRequest request, PageModel model, HttpSession session) {
		String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + UploadControllerCovidModule.covidFolder;
		System.out.println("*******DummyDataImportPageController, folder: " + folderLocation);
		//createConcept(request);
	}
	
}
