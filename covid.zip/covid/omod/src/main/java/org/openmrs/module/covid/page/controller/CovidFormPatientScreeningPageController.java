package org.openmrs.module.covid.page.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.openmrs.Concept;
import org.openmrs.api.context.Context;
import org.openmrs.ui.framework.page.PageModel;
import org.springframework.web.bind.annotation.RequestParam;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * @author barrylevine
 */
public class CovidFormPatientScreeningPageController {
	
	RestPostGet restCall = new RestPostGet();
	
	String restUserName = "restuser";
	
	String restUserPassword = "$kl@*Akjkj3344";
	
	String baseURL, locationUUID, patientUUID, visitTypeUUID, encounterTypeUUID;
	
	public void controller(HttpServletRequest request, PageModel model, HttpSession session) {
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		baseURL = url.substring(0, contextPathIndex) + contextPath;
		baseURL = baseURL + "/ws/rest/v1/";
		if (!baseURL.contains("localhost")) {
			baseURL = baseURL.replace("http:", "https:");
		}
		//getLocationsFromServer();
		//saveLocationToProductionServer();
		
		System.out.println("Context.getLocale().getDisplayName(): " + Context.getLocale().getDisplayName());
	}
	
	private void saveLocationToProductionServer() {
		URL urlForPOST = null;
		try {
			//urlForPOST = new URL("https://pfa.avetis.org/openmrs/ws/rest/v1/location");
			urlForPOST = new URL(baseURL + "location");
			String action = "{ \"name\": \"mylocation\"}";
			System.out
			        .println("saveLocationToProductionServer: url: https://pfastaging.avetis.org/openmrs/ws/rest/v1/location\n"
			                + action);
			String response = null;
			HttpURLConnection postConnJSON = (HttpURLConnection) urlForPOST.openConnection();
			String encoded = Base64.getEncoder().encodeToString(
			    ("restuser" + ":" + "$kl@*Akjkj3344").getBytes(StandardCharsets.UTF_8)); //Java 8
			//encoded = Base64.getEncoder().encodeToString(("admin" + ":" + "Admin123").getBytes(StandardCharsets.UTF_8)); // Java 8
			postConnJSON.setRequestProperty("Authorization", "Basic " + encoded);
			postConnJSON.setDoOutput(true);
			postConnJSON.setRequestMethod("POST");
			postConnJSON.setRequestProperty("Content-Type", "application/json");
			postConnJSON.setRequestProperty("Accept", "application/json");
			OutputStream os = postConnJSON.getOutputStream();
			byte[] input = action.getBytes("utf-8");
			os.write(input, 0, input.length);
			System.out.println("POST Response Message : " + postConnJSON.getResponseMessage());
			
			BufferedReader br = new BufferedReader(new InputStreamReader((postConnJSON.getInputStream())));
			String output, msg = "";
			while ((output = br.readLine()) != null) {
				msg += output;
				System.out.println(output);
			}
			postConnJSON.disconnect();
		}
		catch (Exception ex) {
			System.out.println("****************** GET ISSUE: " + ex);
		}
	}
	
	private void getLocationsFromServer() {
		URL urlForGET = null;
		try {
			//urlForGET = new URL("https://pfastaging.avetis.org/openmrs/ws/rest/v1/location");
			//urlForGET = new URL("http://localhost:8080/openmrs/ws/rest/v1/location");
			urlForGET = new URL(baseURL + "location");
			System.out.println("\n\n\ngetLocationsFromServer\n");
			
			HttpURLConnection getConnJSON = (HttpURLConnection) urlForGET.openConnection();
			
			String encoded = Base64.getEncoder().encodeToString(
			    (restUserName + ":" + restUserPassword).getBytes(StandardCharsets.UTF_8)); // Java 8
			
			getConnJSON.setRequestProperty("Authorization", "Basic " + encoded);
			getConnJSON.setDoOutput(true);
			getConnJSON.setRequestMethod("GET");
			getConnJSON.setRequestProperty("Content-Type", "application/json");
			getConnJSON.getInputStream();
			
			int jSonResponse = getConnJSON.getResponseCode();
			int code = getConnJSON.getResponseCode();
			if (getConnJSON.getResponseCode() >= 300) {
				throw new RuntimeException("Failed : HTTP error code : " + getConnJSON.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((getConnJSON.getInputStream())));
			String output, msg = "";
			//System.out.println("Output from Server .... \n");
			//System.out.println("Response Code: " + connectionToURL.getResponseCode());
			while ((output = br.readLine()) != null) {
				msg += output;
				System.out.println(output);
			}
			getConnJSON.disconnect();
			
		}
		catch (Exception ex) {
			System.out.println("****************** GET ISSUE: " + ex);
		}
	}
	
	public String post(HttpSession session, HttpServletRequest request,
	        @RequestParam(value = "patientName", required = false) String patientName) {
		System.out.println("\n\nPOSTING CovidFormPatientScreeningPageController: " + patientName + "\n\n\n");
		
		/*
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonData);
		JsonObject obj = jsEl.getAsJsonObject();
		String conceptUUID = obj.get("display").getAsString();
		System.out.println("\n\nCONCEPT display: " + conceptUUID);
		JsonArray resultArray = obj.getAsJsonArray("vitals");
		for (JsonElement resultElement : resultArray) {
		obj = resultElement.getAsJsonObject();
		obj.entrySet();
		Set<Map.Entry<String, JsonElement>> entries = obj.entrySet();
		for (Map.Entry<String, JsonElement> entry : entries) {
		System.out.println(entry.getKey() + " " + obj.get(entry.getKey()).getAsString());
		}
		//System.out.println("heartRate as int: " + obj.get("heartRate").getAsInt());
		}
		*/
		return "redirect:" + "covid/covidFormPatientScreening.page";
	}
}
