package org.openmrs.module.covid.web.controller;

import java.util.Date;
import org.openmrs.Concept;
import org.openmrs.Drug;
import org.openmrs.Encounter;
import org.openmrs.OrderFrequency;
import org.openmrs.Patient;
import org.openmrs.User;
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.DrugOrderBL;
import org.openmrs.module.covid.DrugOrderBLREST;
import org.openmrs.module.covid.api.DrugOrderBLService;
import org.openmrs.module.webservices.rest.web.RequestContext;
import org.openmrs.module.webservices.rest.web.RestConstants;
import org.openmrs.module.webservices.rest.web.annotation.PropertyGetter;
import org.openmrs.module.webservices.rest.web.annotation.Resource;
import org.openmrs.module.webservices.rest.web.representation.DefaultRepresentation;
import org.openmrs.module.webservices.rest.web.representation.FullRepresentation;
import org.openmrs.module.webservices.rest.web.representation.Representation;
import org.openmrs.module.webservices.rest.web.resource.impl.DataDelegatingCrudResource;
import org.openmrs.module.webservices.rest.web.resource.impl.DelegatingResourceDescription;
import org.openmrs.module.webservices.rest.web.response.ResponseException;

/**
 * @author barrylevine
 */
@Resource(name = RestConstants.VERSION_1 + "/drugordercovidbl", supportedClass = DrugOrderBLREST.class, supportedOpenmrsVersions = {
        "2.0.*", "2.1.*", "2.2.*", "2.3.*", "2.4.*" })
public class DrugOrderCovidResource extends DataDelegatingCrudResource<DrugOrderBLREST> {
	
	/*
	curl -u admin:Admin123  -X POST "http://localhost:8081/openmrs/ws/rest/v1/drugordercovidbl" 
	-H  "accept: application/json" 
	-H  "content-type: application/json" 
	-d "{\"drugUUID\": \"4ad40e0f-d36c-4e3a-8406-08e6c7fae298\",  
	\"dose\": \"2.5\", \"doseUnitsConceptUUID\": \"5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\", 
	\"frequencyUUID\": \"162135OFAAAAAAAAAAAAAAA\", \"durationUnitsConceptUUID\": \"5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\", 
	\"encounterUUID\": \"6f8a9281-3a77-4423-8f7a-d283b6c77e06\", 
	\"userUUID\": \"67bfd7f0-0508-11e3-8ffd-0800200c9a66\", \"patientUUID\": \"c2661bd3-b586-4d56-b46a-d4fe0cc1faf6\", 
	\"duration\": \"1.5\"}"

	*/
	
	@Override
	public DrugOrderBLREST getByUniqueId(String string) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
	@Override
	protected void delete(DrugOrderBLREST t, String string, RequestContext rc) throws ResponseException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
	@Override
	public void purge(DrugOrderBLREST t, RequestContext rc) throws ResponseException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
	@Override
	public DelegatingResourceDescription getRepresentationDescription(Representation r) {
		if (r instanceof DefaultRepresentation) {
			DelegatingResourceDescription description = new DelegatingResourceDescription();
			description.addProperty("patientUUID");
			description.addProperty("drugUUID");
			description.addLink("default", ".?v=" + RestConstants.REPRESENTATION_DEFAULT);
			description.addSelfLink();
			return description;
		} else if (r instanceof FullRepresentation) {
			DelegatingResourceDescription description = new DelegatingResourceDescription();
			description.addProperty("patientUUID");
			description.addProperty("drugUUID");
			description.addLink("full", ".?v=" + RestConstants.REPRESENTATION_FULL);
			description.addSelfLink();
			return description;
		}
		return null;
	}
	
	@Override
	public DrugOrderBLREST newDelegate() {
		System.out.println("****************newDelegate: ");
		return new DrugOrderBLREST();
	}
	
	@Override
	public DrugOrderBLREST save(DrugOrderBLREST t) {
		System.out.println("****************SAVE: " + t.getDrugUUID() + " " + t.getPatientUUID());
		DrugOrderBL drugOrder = new DrugOrderBL();
		Drug drug = Context.getConceptService().getDrugByUuid(t.getDrugUUID());
		drugOrder.setDrugId(drug.getDrugId());
		drugOrder.setDose(t.getDose());
		Concept doseUnitsConcept = Context.getConceptService().getConceptByUuid(t.getDoseUnitsConceptUUID());
		drugOrder.setDoseUnitsConceptId(doseUnitsConcept.getConceptId());
		OrderFrequency frequency = Context.getOrderService().getOrderFrequencyByUuid(t.getFrequencyUUID());
		drugOrder.setOrderFrequencyId(frequency.getId());
		Concept durationUnitsConcept = Context.getConceptService().getConceptByUuid(t.getDurationUnitsConceptUUID());
		drugOrder.setDurationUnitsConceptId(durationUnitsConcept.getConceptId());
		drugOrder.setDuration(t.getDuration());
		Encounter enc = Context.getEncounterService().getEncounterByUuid(t.getEncounterUUID());
		drugOrder.setEncounterId(enc.getEncounterId());
		Patient patient = Context.getPatientService().getPatientByUuid(t.getPatientUUID());
		drugOrder.setPatientId(patient.getId());
		
		User user = Context.getUserService().getUserByUuid(t.getUserUUID());
		drugOrder.setOrdererUserId(user.getId());
		drugOrder.setDateCreated(new Date());
		
		Context.getService(DrugOrderBLService.class).saveDrugOrder(drugOrder);
		return t;
	}
	
	@PropertyGetter("display")
	public String getDisplayString(DrugOrderBLREST item) {
		return item.getPatientUUID();
	}
	
	@Override
	public DelegatingResourceDescription getCreatableProperties() {
		DelegatingResourceDescription description = new DelegatingResourceDescription();
		description.addProperty("drugUUID");
		description.addProperty("dose");
		description.addProperty("doseUnitsConceptUUID");
		description.addProperty("frequencyUUID");
		description.addProperty("durationUnitsConceptUUID");
		description.addProperty("duration");
		description.addProperty("encounterUUID");
		description.addProperty("userUUID");
		description.addProperty("patientUUID");
		description.addProperty("dateCreated");
		
		return description;
	}
	
}
