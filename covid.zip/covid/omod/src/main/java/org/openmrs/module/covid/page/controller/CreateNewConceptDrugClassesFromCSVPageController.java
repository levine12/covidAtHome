/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid.page.controller;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.openmrs.Concept;
import org.openmrs.ConceptClass;
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.web.controller.UploadControllerCovidModule;
import org.openmrs.ui.framework.page.PageModel;
import org.openmrs.ui.framework.page.PageRequest;
import org.openmrs.util.OpenmrsUtil;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author barrylevine
 */
public class CreateNewConceptDrugClassesFromCSVPageController {
	
	public void controller(HttpServletRequest request, PageModel pageModel, PageRequest pageRequest) {
		String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + UploadControllerCovidModule.covidFolder;
		System.out.println("\n\nCreateNewConceptDrugClassesPageController: " + folderLocation);
		ArrayList<String> results = new ArrayList<String>();
		File folder = new File(folderLocation);
		File[] files = folder.listFiles();
		
		//If this pathname does not denote a directory, then listFiles() returns null.
		if (files != null) {
			for (File file : files) {
				if (!file.isFile()) {
					continue;
				}
				System.out.println("CHECKING " + file.getName());
				String fileName = file.getName().toLowerCase();
				if (!fileName.startsWith(".") && fileName.contains("classes")) {
					results.add(file.getName());
				}
			}
		}
		results.add("NEWaa");
		pageModel.addAttribute("files", results);
		//checkReplacingConceptClassForConcept("Aspirin", "steroid");
	}
	
	private void checkReplacingConceptClassForConcept(String conceptName, String newClassName) {
		List<ConceptClass> classes = Context.getConceptService().getAllConceptClasses();
		ConceptClass conceptClass = null;
		for (ConceptClass oldClass : classes) {
			String oldClassName = oldClass.getName().trim();
			oldClassName = oldClassName;
			System.out.println("CHECKING OLDCLASS NAME: " + oldClassName + " " + oldClassName.length() + "  NEW NAME: "
			        + newClassName + " " + newClassName.length());
			if (oldClassName.equals(newClassName)) {
				conceptClass = oldClass;
				break;
			}
		}
		
		Concept concept = Context.getConceptService().getConceptByName(conceptName);
		concept.setConceptClass(conceptClass);
		System.out.println("nw conceptclass " + concept.getConceptClass().getName());
		Context.getConceptService().saveConcept(concept);
	}
	
	public String post(HttpSession session, HttpServletRequest request,
	        @RequestParam(value = "conceptClassCsvFile", required = false) String conceptClassCsvFile) {
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		String baseURL = url.substring(0, contextPathIndex) + contextPath;
		baseURL = baseURL + "/ws/rest/v1/";
		//USE .TXT FILE FOR CONCEPT CLASSES - MIGHT HELP WITH BAD CHARS
		System.out.println("POST ------------ CreateConceptsFromCSVPageController: " + conceptClassCsvFile + "\n\n"
		        + baseURL + "\n");
		
		try {
			String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + "/"
			        + UploadControllerCovidModule.covidFolder;
			File folder = new File(folderLocation);
			File file = new File(folder, conceptClassCsvFile);
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
			System.out.println("\n\nHERE\n\n");
			String nextLine;
			while (((nextLine = in.readLine()) != null) && (!nextLine.replace(",", "").equals(""))) {
				System.out.println("\n\nADDING: " + nextLine + "\n\n");
				addConceptDrugClass(nextLine.trim());
			}
			in.close();
		}
		catch (Exception e) {
			System.out.println("POST: " + e);
		}
		
		return "redirect:" + "covid/createNewConceptDrugClassesFromCSV.page";
	}
	
	private void addConceptDrugClass(String conceptClassName) {
		// sometimes there is an unprintable character in the new class name obtained from the csv
		
		conceptClassName = removeBadChars(conceptClassName);
		//for (int i = 0; i < conceptClassName.length(); i++) {
		//	System.out.println("\n\ni: " + i + "  char at i: " + Integer.toHexString(conceptClassName.charAt(i)));
		//}
		if (isConceptClassAlreadyAdded(conceptClassName)) {
			return;
		}
		System.out.println("addConceptDrugClass " + conceptClassName + conceptClassName.length());
		ConceptClass newConceptClass = new ConceptClass();
		newConceptClass.setName(conceptClassName);
		newConceptClass = Context.getConceptService().saveConceptClass(newConceptClass);
		System.out.println("addedConceptDrugClass " + newConceptClass.getName() + newConceptClass.getName().length());
	}
	
	private String removeBadChars(String oldString) {
		oldString = oldString.trim();
		String newString = "";
		for (int i = 0; i < oldString.length(); i++) {
			if (Integer.toHexString(oldString.charAt(i)).length() == 2) {
				newString += oldString.charAt(i);
				continue;
			}
		}
		return newString;
	}
	
	private boolean isConceptClassAlreadyAdded(String conceptClassName) {
		List<ConceptClass> classes = Context.getConceptService().getAllConceptClasses();
		for (ConceptClass oldClass : classes) {
			if (oldClass.getName().equals(conceptClassName)) {
				System.out.println("\nCONCEPT CLASS ALREADY ADDED: " + conceptClassName);
				return true;
			}
		}
		return false;
	}
	
}
