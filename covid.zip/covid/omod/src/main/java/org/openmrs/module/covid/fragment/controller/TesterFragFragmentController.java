/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid.fragment.controller;

import org.openmrs.ui.framework.fragment.FragmentModel;

/**
 * @author barrylevine
 */
public class TesterFragFragmentController {
	
	public void controller(FragmentModel model) {
		
	}
}
