/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid.fragment.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.lucene.store.MMapDirectory;
import org.openmrs.Concept;
import org.openmrs.Drug;
import org.openmrs.Encounter;
import org.openmrs.EncounterType;
import org.openmrs.Location;
import org.openmrs.Obs;
import org.openmrs.Patient;
import org.openmrs.Person;
import org.openmrs.PersonAttributeType;
import org.openmrs.User;
import org.openmrs.Visit;
import org.openmrs.VisitType;
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.page.controller.RestPostGet;
import org.openmrs.ui.framework.fragment.FragmentModel;

/**
 * @author barrylevine
 */
public class CovidFormDischargePlanFragFragmentController {
	
	RestPostGet restCall = new RestPostGet();
	
	String baseURL;
	
	String patientIdURL;
	
	//String restUserName = "restuser";
	String restUserName = "admin";
	
	//String restUserPassword = "$kl@*Akjkj3344";
	String restUserPassword = "Admin123";
	
	String yesConceptUUID = Context.getConceptService().getConceptByName("Yes").getUuid();
	
	String noConceptUUID = Context.getConceptService().getConceptByName("No").getUuid();
	
	public void controller(HttpServletRequest request, FragmentModel model) {
		if (Context.getLocale().getDisplayName().equals("Armenian")) {
			model.addAttribute("phrases", new TranslationArmenian());
		} else {
			model.addAttribute("phrases", new TranslationEnglish());
		}
		List<Drug> drugs = Context.getConceptService().getAllDrugs();
		List<Drug> steroids = new ArrayList<Drug>();
		List<Drug> antibiotics = new ArrayList<Drug>();
		List<Drug> anticoagulation = new ArrayList<Drug>();
		List<Drug> antihyperglycemics = new ArrayList<Drug>();
		for (Drug drug : drugs) {
			Concept drugConcept = drug.getConcept();
			if (drugConcept.getConceptClass().getName().equals("Antibiotic")) {
				antibiotics.add(drug);
			}
		}
		
		model.addAttribute("drugs", drugs);
		model.addAttribute("antibiotics", antibiotics);
		
	}
	
}
