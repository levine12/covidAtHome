package org.openmrs.module.covid.page.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * @author levine
 */
public class RestPostGet {
	
	//String restUserName = "restuser";
	String restUserName = "admin";
	
	//String restUserPassword = "$kl@*Akjkj3344";
	String restUserPassword = "Admin123";
	
	public String doPostRestCall(String url, String action) {
		if (!url.contains("localhost")) {
			url = url.replace("http:", "https:");
		}
		System.out.println("DOPOSTRESTCALL: restUserName: " + restUserName + "  url: " + url + " \n" + action);
		String response = null;
		
		try {
			URL urlForPost = new URL(url);
			
			HttpURLConnection postConnJSON = (HttpURLConnection) urlForPost.openConnection();
			
			System.out.println("\nPOST: " + restUserName + " " + restUserPassword + url + "\n" + action);
			String encoded = Base64.getEncoder().encodeToString(
			    (restUserName + ":" + restUserPassword).getBytes(StandardCharsets.UTF_8)); //Java 8
			//encoded = Base64.getEncoder().encodeToString(("admin" + ":" + "Admin123").getBytes(StandardCharsets.UTF_8)); // Java 8
			postConnJSON.setRequestProperty("Authorization", "Basic " + encoded);
			postConnJSON.setDoOutput(true);
			postConnJSON.setRequestMethod("POST");
			postConnJSON.setRequestProperty("Content-Type", "application/json");
			postConnJSON.setRequestProperty("Accept", "application/json");
			OutputStream os = postConnJSON.getOutputStream();
			byte[] input = action.getBytes("utf-8");
			os.write(input, 0, input.length);
			System.out.println("POST Response Message : " + postConnJSON.getResponseMessage());
			
			response = getRestResponse(postConnJSON);
		}
		catch (Exception ex) {
			System.out.println("****************** POST ISSUE: " + ex);
			
		}
		return response;
	}
	
	public String doGetRestCall(String url) {
		if (!url.contains("localhost")) {
			url = url.replace("http:", "https:");
		}
		URL urlForGET = null;
		try {
			urlForGET = new URL(url);
			
			HttpURLConnection getConnJSON = (HttpURLConnection) urlForGET.openConnection();
			
			String encoded = Base64.getEncoder().encodeToString(
			    (restUserName + ":" + restUserPassword).getBytes(StandardCharsets.UTF_8)); // Java 8
			System.out.println("\nGET: " + url);
			getConnJSON.setRequestProperty("Authorization", "Basic " + encoded);
			
			//getConnJSON.setRequestProperty("Authorization", "Basic");
			getConnJSON.setDoOutput(true);
			getConnJSON.setRequestMethod("GET");
			getConnJSON.setRequestProperty("Content-Type", "application/json");
			getConnJSON.getInputStream();
			
			int jSonResponse = getConnJSON.getResponseCode();
			return getRestResponse(getConnJSON);
		}
		catch (Exception ex) {
			System.out.println("****************** GET ISSUE: " + ex);
		}
		return null;
	}
	
	public String doDeleteRestCall(String url) {
		if (!url.contains("localhost")) {
			url = url.replace("http:", "https:");
		}
		URL urlForDELETE = null;
		try {
			urlForDELETE = new URL(url);
			
			HttpURLConnection getConnJSON = (HttpURLConnection) urlForDELETE.openConnection();
			
			String encoded = Base64.getEncoder().encodeToString(
			    (restUserName + ":" + restUserPassword).getBytes(StandardCharsets.UTF_8)); // Java 8
			System.out.println("\nDELETE: " + url);
			getConnJSON.setRequestProperty("Authorization", "Basic " + encoded);
			getConnJSON.setRequestProperty("Accept", "application/json");
			//getConnJSON.setRequestProperty("Authorization", "Basic");
			getConnJSON.setDoOutput(true);
			getConnJSON.setRequestMethod("DELETE");
			//getConnJSON.setRequestProperty("Content-Type", "application/json");
			getConnJSON.getInputStream();
			
			int jSonResponse = getConnJSON.getResponseCode();
			return getRestResponse(getConnJSON);
		}
		catch (Exception ex) {
			System.out.println("****************** GET ISSUE: " + ex);
		}
		return null;
	}
	
	private String getRestResponse(HttpURLConnection connectionToURL) throws IOException {
		int code = connectionToURL.getResponseCode();
		if (connectionToURL.getResponseCode() >= 300) {
			throw new RuntimeException("Failed : HTTP error code : " + connectionToURL.getResponseCode());
		}
		BufferedReader br = new BufferedReader(new InputStreamReader((connectionToURL.getInputStream())));
		String output, msg = "";
		//System.out.println("Output from Server .... \n");
		//System.out.println("Response Code: " + connectionToURL.getResponseCode());
		while ((output = br.readLine()) != null) {
			msg += output;
			//System.out.println(output);
		}
		connectionToURL.disconnect();
		return msg;
	}
	
}
