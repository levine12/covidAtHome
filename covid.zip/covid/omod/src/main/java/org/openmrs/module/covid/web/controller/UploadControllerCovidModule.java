/**
 * This Source Code Form is subject to the terms of the Mozilla Public License,
 * v. 2.0. If a copy of the MPL was not distributed with this file, You can
 * obtain one at http://mozilla.org/MPL/2.0/. OpenMRS is also distributed under
 * the terms of the Healthcare Disclaimer located at http://openmrs.org/license.
 *
 * Copyright (C) OpenMRS Inc. OpenMRS is a registered trademark and the OpenMRS
 * graphic logo is a trademark of OpenMRS Inc.
 */
package org.openmrs.module.covid.web.controller;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gson.JsonObject;

import org.openmrs.util.OpenmrsUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * This class configured as controller using annotation and mapped with the URL of
 * 'module/document/documentLink.form'.
 */
//@Controller("${rootrootArtifactId}.UploadControllerArmeniaModule")
@Controller
@RequestMapping(value = "covid/uploadcovidmodule.form")
public class UploadControllerCovidModule {
	
	public static String covidFolder = "Covid";
	
	/**
	 * Logger for this class and subclasses
	 */
	protected final Log log = LogFactory.getLog(getClass());
	
	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	public void onGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "This method is not allowed.");
	}
	
	@RequestMapping(method = RequestMethod.POST)
	@ResponseBody
	public String onPost(HttpServletRequest request, @RequestParam("file") String fileDataUrl,
	        @RequestParam("filename") String fileName, HttpServletResponse response) {
		
		System.out.println("UploadControllerxxx: onPost  fileName: " + fileName);
		
		JsonObject jsonObject = new JsonObject();
		try {
			File file = getFile(fileDataUrl, fileName);
			
			jsonObject.addProperty("result", "success");
		}
		catch (IOException e) {
			e.printStackTrace();
			jsonObject.addProperty("result", "failed");
		}
		try {
			printFile(fileDataUrl, fileName);
		}
		catch (IOException e) {
			e.printStackTrace();
			jsonObject.addProperty("result", "failed");
		}
		return jsonObject.toString();
	}
	
	private File getFile(String fileDataUrl, String fileName) throws IOException {
		String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + "/" + covidFolder;
		System.out.println("GETFILE FOLDERLOCATION: " + folderLocation);
		File folder = new File(folderLocation);
		folder.mkdirs();
		
		File file = new File(folder, fileName);
		BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(file));
		fileDataUrl = fileDataUrl.substring(fileDataUrl.indexOf(",") + 1);
		stream.write(Base64.decodeBase64(fileDataUrl.getBytes()));
		stream.close();
		
		return file;
	}
	
	private void printFile(String fileDataUrl, String fileName) throws IOException {
		String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + "/" + covidFolder;
		File folder = new File(folderLocation);
		File file = new File(folder, fileName);
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
		
		String str;
		
		while ((str = in.readLine()) != null) {
			String[] items = str.split(",");
			//System.out.println("First: " + items[8 - 1] + " Last: " + items[9 - 1] + " Birth: " + items[12 - 1] + "/"
			//        + items[13 - 1] + "/" + items[14 - 1]);
			System.out.println(str);
		}
		
		in.close();
	}
}
