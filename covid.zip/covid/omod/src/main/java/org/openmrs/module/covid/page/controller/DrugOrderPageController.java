package org.openmrs.module.covid.page.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.openmrs.Concept;
import org.openmrs.Drug;
import org.openmrs.api.APIException;
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.DrugOrderBL;
import org.openmrs.module.covid.api.DrugOrderBLService;
import org.openmrs.ui.framework.page.PageModel;

/**
 * @author barrylevine
 */
public class DrugOrderPageController {
	
	public void controller(HttpServletRequest request, PageModel model, HttpSession session) {
		Concept aspirinConcept = Context.getConceptService().getConceptByName("Aspirin");
		
		//createDrugOrderAPI();
		//createDrugOrderREST();
		
	}
	
	private void createDrugOrderREST() {
		RestPostGet restCall = new RestPostGet();
		String urlPost = "http://localhost:8081/openmrs/ws/rest/v1/drugordercovidbl";
		String urlGet = "http://localhost:8081/openmrs/ws/rest/v1/drugorderbl";
		/*
		        
		        curl -u admin:Admin123  -X POST "http://localhost:8081/openmrs/ws/rest/v1/drug" 
		        -H  "accept: application/json" 
		        -H  "content-type: application/json" 
		        -d "{
		        \"name\": \"Drug name\",   
		        \"combination\": \"false\", 
		        \"concept\": \"71617AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\"}"
		        
		        
		    curl -u admin:Admin123  -X POST "http://localhost:8081/openmrs/ws/rest/v1/drugordercovidbl" 
		    -H  "accept: application/json" 
		    -H  "content-type: application/json" 
		    -d "{
		    \"drugUUID\": \"4ad40e0f-d36c-4e3a-8406-08e6c7fae298\",   
		    \"dose\": \"2.5\", 
		    \"doseUnitsConceptUUID\": \"5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\", 
		    \"frequencyUUID\": \"162135OFAAAAAAAAAAAAAAA\", 
		    \"durationUnitsConceptUUID\": \"5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\", 
		    \"encounterUUID\": \"6f8a9281-3a77-4423-8f7a-d283b6c77e06\", 
		    \"userUUID\": \"67bfd7f0-0508-11e3-8ffd-0800200c9a66\", 
		    \"patientUUID\": \"c2661bd3-b586-4d56-b46a-d4fe0cc1faf6\", 
		    \"duration\": \"1.5\"}"

		     curl -u admin:Admin123 -X GET "http://localhost:8081/openmrs/ws/rest/v1/drugorderbl"  -H  "accept: application/json"
		 */
		
		String action = "{" + "\"drugUUID\": \"4ad40e0f-d36c-4e3a-8406-08e6c7fae298\",   " + "\"dose\": \"27.5\", "
		        + "\"doseUnitsConceptUUID\": \"5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\", "
		        + "\"frequencyUUID\": \"162135OFAAAAAAAAAAAAAAA\", "
		        + "\"durationUnitsConceptUUID\": \"5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\", "
		        + "\"encounterUUID\": \"6f8a9281-3a77-4423-8f7a-d283b6c77e06\", "
		        + "\"userUUID\": \"67bfd7f0-0508-11e3-8ffd-0800200c9a66\", "
		        + "\"patientUUID\": \"c2661bd3-b586-4d56-b46a-d4fe0cc1faf6\", " + "\"duration\": \"12.5\"}";
		
		System.out.println("\n\n\n-----------------------------------------------------------\n\n"
		        + "\n\n\n-----------------------------------------------------------\n\n");
		
		String jsonResponse = restCall.doGetRestCall(urlGet);
		System.out.println("\n\n\ndoGetRestCall:\n" + jsonResponse + "\n\n");
		
		jsonResponse = restCall.doPostRestCall(urlPost, action);
		System.out.println("\n\n\ndoPostRestCall action:\n" + jsonResponse + "\n\n");
		
		jsonResponse = restCall.doGetRestCall(urlGet);
		System.out.println("\n\n\ndoGetRestCall:\n" + jsonResponse + "\n\n");
	}
	
	private void createDrugOrderAPI() throws APIException {
		DrugOrderBL order = new DrugOrderBL();
		order.setPatientId(7);
		order.setDrugId(1);
		order.setEncounterId(1);
		order.setOrdererUserId(4);
		/*
		String allowedLocales = Context.getAdministrationService().getGlobalProperty("locale.allowed.list");
		System.out.println("\n\nlocales: " + Context.getAdministrationService().getGlobalProperty("locale.allowed.list"));
		if (!allowedLocales.contains("hy")) {
		allowedLocales += ", en_GB , hy";
		Context.getAdministrationService().setGlobalProperty("locale.allowed.list", allowedLocales);
		}
		System.out.println("\n\nlocales: " + Context.getAdministrationService().getGlobalProperty("locale.allowed.list"));
		 */
		/*
			       order.setOrderFrequencyId(2);
			       order.setDose_unitsConcept(5089);
			       order.setQuantity_unitsConceptId(5090);
			       order.setRouteConceptId(5089);
		        */
		DrugOrderBL orderBL = Context.getService(DrugOrderBLService.class).saveDrugOrder(order);
	}
	
	private void testObsgroup(HttpServletRequest request) {
		String action = "{\"person\": \"087452d1-5c60-42b2-9144-f25c717367b2\", "
		        + "\"obsDatetime\": \"2021-02-01\", \"concept\": \"2cb468f3-0210-4388-862a-804f7dd1e4c6\", "
		        + "\"location\": \"b1a8b05e-3542-4037-bbd3-998ee9c40574\", "
		        + "\"groupMembers\": [\"14c2cb74-fdb0-497f-ba98-3412211e2fc5\", \"811eeb26-36b1-4fa6-9e53-644c96f99341\"  ]}";
		
		RestPostGet restCall = new RestPostGet();
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		String baseUrl1 = url.substring(0, contextPathIndex) + contextPath;
		String baseURL = baseUrl1 + "/ws/rest/v1/";
		String jsonResponse = restCall.doPostRestCall(baseURL + "obs", action);
		System.out.println("\n\n\nOBSGROUP\n" + jsonResponse);
	}
}
