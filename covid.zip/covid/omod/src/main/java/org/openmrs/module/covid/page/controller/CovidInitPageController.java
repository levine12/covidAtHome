/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid.page.controller;

import javax.servlet.http.HttpServletRequest;
import org.openmrs.Concept;
import org.openmrs.api.context.Context;
import org.openmrs.ui.framework.fragment.FragmentModel;

/**
 * @author barrylevine
 */
public class CovidInitPageController {
	
	RestPostGet restCall = new RestPostGet();
	
	String baseURL;
	
	public void controller(HttpServletRequest request, FragmentModel model) {
		purgeBadYesNoConcepts();
	}
	
	private void purgeBadYesNoConcepts() {
		Concept badYesConcept = Context.getConceptService().getConcept(1);
		System.out.println("badYesConcept: " + badYesConcept.getName() + " id: " + badYesConcept.getConceptId());
		Concept badNoConcept = Context.getConceptService().getConcept(2);
		String badYesConceptUUID = badYesConcept.getUuid();
		String badNoConceptUUID = badNoConcept.getUuid();
		String deleteURL = baseURL + "/concept/" + badYesConceptUUID + "?purge-true";
		String jsonResponse = restCall.doDeleteRestCall(deleteURL);
		deleteURL = baseURL + "/concept/" + badNoConceptUUID + "?purge-true";
		jsonResponse = restCall.doDeleteRestCall(deleteURL);
		System.out.println("DELETE CONCEPT: " + jsonResponse);
		
		Concept yesConcept = Context.getConceptService().getConceptByName("yes");
		System.out.println("YES CONCEPT: " + yesConcept.getName() + " " + yesConcept.getConceptId());
		Concept noConcept = Context.getConceptService().getConceptByName("no");
		System.out.println("NO CONCEPT: " + noConcept.getName() + " " + noConcept.getConceptId());
	}
	
}
