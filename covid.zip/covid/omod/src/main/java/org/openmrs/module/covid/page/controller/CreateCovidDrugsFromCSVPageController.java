/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid.page.controller;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.openmrs.Concept;
import org.openmrs.ConceptClass;
import org.openmrs.ConceptDatatype;
import org.openmrs.Drug;
import org.openmrs.api.APIException;
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.web.controller.UploadControllerCovidModule;
import org.openmrs.ui.framework.page.PageModel;
import org.openmrs.ui.framework.page.PageRequest;
import org.openmrs.util.OpenmrsUtil;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author barrylevine
 */
public class CreateCovidDrugsFromCSVPageController {
	
	private static int englishNameColumn = 0;
	
	private static int armenianNameColumn = 1;
	
	private static int conceptClassNameColumn = 2;
	
	String baseURL;
	
	RestPostGet restCall = new RestPostGet();
	
	public void controller(HttpServletRequest request, PageModel pageModel, PageRequest pageRequest) {
		String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + "/" + UploadControllerCovidModule.covidFolder;
		ArrayList<String> results = new ArrayList<String>();
		File folder = new File(folderLocation);
		File[] files = folder.listFiles();
		
		//If this pathname does not denote a directory, then listFiles() returns null.
		if (files != null) {
			for (File file : files) {
				if (!file.isFile()) {
					continue;
				}
				String fileName = file.getName().toLowerCase();
				if (!file.getName().startsWith(".") && file.getName().contains("drug")) {
					results.add(file.getName());
				}
			}
		}
		results.add("NEWaa");
		
		String urlPathToPage = (request.getRequestURL().toString()).trim();
		urlPathToPage = urlPathToPage.substring(0, urlPathToPage.lastIndexOf("/") + 1);
		pageModel.addAttribute("files", results);
		pageModel.addAttribute("url", urlPathToPage);
	}
	
	//First column is name/english, second column is name/armenian, third column is drug class
	// assume all drug classes have already been added
	// datatype of drug concept is N/A
	public String post(HttpSession session, HttpServletRequest request,
	        @RequestParam(value = "drugCsvFile", required = false) String drugCsvFile) {
		/*
		    First column is name/english, second column is name/armenian, third column is drug class
		 */
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		baseURL = url.substring(0, contextPathIndex) + contextPath;
		baseURL = baseURL + "/ws/rest/v1/";
		System.out
		        .println("\n\n\n\n\n*****************************************************************************************\n------------ CreateConceptsFromCSVPageController\n");
		
		try {
			String folderLocation = OpenmrsUtil.getApplicationDataDirectory() + "/"
			        + UploadControllerCovidModule.covidFolder;
			File folder = new File(folderLocation);
			File file = new File(folder, drugCsvFile);
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
			System.out.println("\n\nHERE\n\n");
			String nextLine;
			while (((nextLine = in.readLine()) != null) && (!nextLine.replace(",", "").equals(""))) {
				System.out.println("\n\nADDING: " + nextLine + "\n\n");
				createDrug(nextLine.trim());
				
				//updateArmenianIfNecessary(request, concept, conceptInfo);
			}
			in.close();
		}
		catch (Exception e) {
			System.out.println("POST: " + e);
		}
		
		return "redirect:" + "covid/createCovidDrugsFromCSV.page";
	}
	
	private void createDrug(String nextLine) {
		String[] lineData = nextLine.split(",");
		String nameEnglish = lineData[englishNameColumn].trim();
		nameEnglish = removeBadChars(nameEnglish);
		String drugClassName = lineData[conceptClassNameColumn];
		drugClassName = removeBadChars(drugClassName);
		System.out.println("\nEnglish: " + nameEnglish + " drug class: " + drugClassName);
		if (drugAleadyAdded(nameEnglish)) {
			return;
		}
		addDrug(nameEnglish, drugClassName);
		
		//List<ConceptDatatype> datatypes = Context.getConceptService().getAllConceptDatatypes();
		// get uuid of "N/A"
		// CHECK IF NEED TO ADD CONCEPT, AS WELL
	}
	
	private void addDrug(String nameEnglish, String drugClassName) {
		Concept drugConcept = getDrugConcept(nameEnglish, drugClassName);
		Drug drug = new Drug();
		drug.setConcept(drugConcept);
		drug.setName(drugConcept.getDisplayString());
		drug = Context.getConceptService().saveDrug(drug);
		System.out.println("\n\nNEW DRUG: " + drug);
		return;
	}
	
	private Concept getDrugConcept(String nameEnglish, String drugClassName) throws APIException {
		List<Concept> concepts = Context.getConceptService().getConceptsByName(nameEnglish);
		if ((concepts != null) && (concepts.size() > 0) && concepts.get(0).getDisplayString().equals(nameEnglish)) {
			System.out.println("\nFOUND DRUG CONCEPT: " + concepts.get(0).getDisplayString());
			return concepts.get(0);
		}
		System.out.println("\nNOT FOUND DRUG CONCEPT: " + nameEnglish);
		return addDrugConcept(nameEnglish, drugClassName);
	}
	
	private Concept addDrugConcept(String nameEnglish, String drugClassName) {
		String conceptDatatypeUUID = null;
		List<ConceptDatatype> datatypes = Context.getConceptService().getAllConceptDatatypes();
		for (ConceptDatatype datatype : datatypes) {
			if (datatype.getName().equals("N/A")) {
				conceptDatatypeUUID = datatype.getUuid();
				break;
			}
		}
		String conceptDrugClassUUID = null;
		List<ConceptClass> classes = Context.getConceptService().getAllConceptClasses();
		for (ConceptClass oldClass : classes) {
			if (oldClass.getName().equals(drugClassName)) {
				System.out.println("\nCONCEPT CLASS ALREADY ADDED: " + drugClassName);
				conceptDrugClassUUID = oldClass.getUuid();
				break;
			}
		}
		String action = "{  \"names\": [    {      \"name\": \"CONCEPTNAMEENGLISH\",      \"locale\": \"en\",      "
		        + "\"localePreferred\": true,      \"conceptNameType\": \"FULLY_SPECIFIED\"    }], "
		        + "\"datatype\": \"DATATYPEUUID\", \"version\": \"1.0\",  "
		        + "\"conceptClass\": \"CONCEPTCLASSUUID\", \"descriptions\": [   {\"description\": \"new drug concept\", \"locale\": \"en\" } ]}";
		action = action.replace("CONCEPTNAMEENGLISH", nameEnglish);
		action = action.replace("DATATYPEUUID", conceptDatatypeUUID);
		action = action.replace("CONCEPTCLASSUUID", conceptDrugClassUUID);
		System.out.println("\n\nACTION:\n" + action);
		
		String jsonResponse = restCall.doPostRestCall(baseURL + "concept", action);
		System.out.println("\n\n\nCreateConceptsFromCSVPageController\n" + jsonResponse);
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonResponse);
		JsonObject obj = jsEl.getAsJsonObject();
		String conceptUUID = obj.get("uuid").getAsString();
		System.out.println("\n\nCONCEPT UUID: " + conceptUUID);
		Concept concept = Context.getConceptService().getConceptByUuid(conceptUUID);
		return concept;
	}
	
	private boolean drugAleadyAdded(String nameEnglish) {
		nameEnglish = removeBadChars(nameEnglish);
		List<Drug> drugs = Context.getConceptService().getAllDrugs();
		for (Drug drug : drugs) {
			String oldDrugName = drug.getDisplayName();
			System.out.println("CHECKING OLD DRUG: " + oldDrugName + " " + oldDrugName.length() + "  " + nameEnglish + " "
			        + nameEnglish.length() + " " + oldDrugName.equals(nameEnglish));
			if (oldDrugName.equals(nameEnglish)) {
				System.out.println("DRUG ALREADY ADDED");
				return true;
			}
		}
		System.out.println("DRUG NOT ADDED");
		return false;
	}
	
	private String removeBadChars(String oldString) {
		oldString = oldString.trim();
		String newString = "";
		for (int i = 0; i < oldString.length(); i++) {
			if (Integer.toHexString(oldString.charAt(i)).length() == 2) {
				newString += oldString.charAt(i);
				continue;
			}
		}
		return newString;
	}
}
