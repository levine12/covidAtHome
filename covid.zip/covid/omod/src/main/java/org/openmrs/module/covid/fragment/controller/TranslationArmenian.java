/*
    I should get a csv for translation:
    first column - variable to use for phrases on web page
    second column - English phrase to use for web page
    third column - Armenian equivalent of the phrase
 */
package org.openmrs.module.covid.fragment.controller;

/**
 * @author barrylevine
 */
public class TranslationArmenian {
	
	// include strings for all of the english phrases here, along with getters
	String covidAtHome = "COVID at Home";
	
	String patientScreening = "Patient Screening";
	
	String formDate = "Date";
	
	String completedBy = "Completed by";
	
	String role = "Role";
	
	String physician = "Physician";
	
	String nurse = "Nurse";
	
	String other = "Other";
	
	String instructions = "Instructions";
	
	String instructions1 = "Please consent the patient to be considered for this program and before completing this form.";
	
	String instructions2 = "Complete this form for each patient who has been identified as a possible candidate by the hospital.";
	
	String instructions3 = "If the patient is eligible for the program, please complete the HOSPITAL HISTORY form and HOSPITAL DISCHARGE form.";
	
	String consent = "Consent";
	
	String consentPhrase = "Has the patient provided consent to participate in the program?";
	
	String yes = "Yes";
	
	String no = "No";
	
	String identifiers = "Identifiers";
	
	String name = "Name";
	
	String dateOfBirth = "Date of Birth";
	
	String gender = "Gender";
	
	String male = "Male";
	
	String female = "Female";
	
	String birthCertificate = "Birth Certificate";
	
	String passport = "Passport";
	
	String idNumber = "Identification Number";
	
	String screening = "Screening";
	
	String inclusionCriteria = "Inclusion Criteria";
	
	String inclusionCriteria1 = "Has the patient tested positive for COVID?";
	
	String inclusionCriteria2 = "On room air, is the patient’s O2 saturation less than 90%?";
	
	String inclusionCriteria3 = "On 5L of oxygen via nasal cannula, is the patient’s O2 saturation greater than or equal to 93%?";
	
	String inclusionCriteria4 = "In the past 48 hours the amount of oxygen the patient needs stayed the same or decreased?";
	
	String inclusionCriteria5 = "Does the patient weigh more than 50kg?";
	
	String exclusionCriteria = "Exclusion Criteria";
	
	String exclusionCriteria6 = "Does the patient have evidence of systemic sepsis (e.g.hypotension, organ failure, etc)?";
	
	String exclusionCriteria7 = "Does the patient require oxygen at baseline of greater than 5L?";
	
	String exclusionCriteria8 = "Is the patient younger than 16 years of age?";
	
	String exclusionCriteria9 = "Does the patient have another reason for staying in the hospital?";
	
	String screeningNote = "If the answer to questions 1 through 5 is yes, AND if the answer to questions 6 through 9 is no, then patient meets criteria to be considered for the program.";
	
	String isPatientEligible = "Is the patient eligible for the program?";
	
	String dailyHomeHealthNote = "Daily Home Health Note";
	
	String providerRecordedVitals = "Provider Recorded Vitals";
	
	String overniteHistory = "Overnight History";
	
	String equipmentIssues = "Equipment Issues";
	
	String patientProvidedDate = "Patient Provided Data";
	
	String time = "Time";
	
	String oxygenSaturation = "Oxygen Saturation";
	
	String respiratoryRate = "Respiratory Rate";
	
	String heartRate = "Heart Rate";
	
	String bloodGlucose = "Blood Glucose (if apropriate)";
	
	String planForPatient = "Plan For Patient";
	
	String stayInProgram = "Stay in program";
	
	String returnToHospital = "Return to hospital";
	
	String safeToDischarge = "Safe to discharge from program";
	
	String followUpOn = "Follow Up On";
	
	String finalNoteForm = "If discharging from program or readmitting patient to hospital please complete discharge note and notify program coordinator";
	
	String plan = "Plan";
	
	String continueTheFollowingMeds = "Continue the following medications";
	
	String ifYesProvideMedInfo = "If yes, provide medication name, dose, number of times per day and number of days left on course";
	
	String steroids = "Steroids";
	
	String antibiotics = "Antibiotics";
	
	String anticoagulation = "Anticooagulation";
	
	String antihyperglycemics = "Antihyperglycemics";
	
	String startFollowingMeds = "Start the following medications:";
	
	String dexamethasone = "Dexamethasone (6mg, daily, for 10 days)";
	
	String ifYesForAntibioticsProvideMedInfo = "If yes for antibiotics, provide medication name, dose, number of times per day and number of days left on course";
	
	String monitorForGlucose = "Does the patient need to be monitored for glucose";
	
	String forProgramUseOnly = "For Program Use Only:";
	
	String oxygen = "Oxygen";
	
	String concentratorId = "Concentrator ID:";
	
	String pulseOxId = "Pulse Oximeter ID";
	
	String initConcentratorSettings = "Initial Concentrator Settings";
	
	String glucoseMonitoring = "Glucose Monitoring";
	
	String requireAtHomeGlucoseMonitoring = "Does the patient require at home glucose monitoring";
	
	String ifYesGlucoseId = "If yes, Glucometer ID:";
	
	String homeInspection = "Home Inspection";
	
	String doesPatientHaveFollowing = "Does the patient have the  following?";
	
	String electricity = "Electricity:";
	
	String phoneInternet = "Phone or Internet:";
	
	String safeHomeEnvirons = "Safe Home Environment";
	
	String ifNoPatientShouldNotBeEnrolled = "If No, the patient should not be enrolled";
	
	String hasPatientBeenEducatedOnFollowing = "Has the patient been educated on the following?";
	
	String whenToSeekMedHelp = "When to seek medical help?";
	
	String whoToContactInEmergency = "Who to contact in emergency?";
	
	String howToUseConcentrator = "How to use the concentrator?";
	
	String howToCheckGlucose = "How to check glucose?";
	
	String howToCheckO2Saturation = "How to check oxygen saturation?";
	
	String howToUseLogBook = "How to use daily log book?";
	
	String smokingDangerWithO2 = "Danger of smoking with oxygen?";
	
	String whoToContactFromProgram = "Who to contact from the program?";
	
	String patientContactInfo = "Patient Contact Information";
	
	String patientAddress = "Patient Address:";
	
	String patientPhoneNumber = "Patient Phone Number:";
	
	String emergencyContacts = "Emergency Contacts";
	
	String contactName = "Contact Name";
	
	String emergencyContactPhoneNumber = "Emergency Contact Phone Number:";
	
	String relationshipToPatient = "Relationship to Patient:";
	
	String hospitalHistory = "Hospital History";
	
	String pastMedicalHistory = "Past Medical History";
	
	String pastSurgicalHistory = "Past Surgical History";
	
	String currentTreatment = "Current Treatment";
	
	String dose = "dose";
	
	String frequency = "frequency";
	
	String length = "length";
	
	String startedOn = "started on";
	
	String antibiotic1 = "Antibiotic #1";
	
	String antibiotic2 = "Antiobiotic @2";
	
	String otherTreatments = "Other Treatment(s)";
	
	String allergies = "Allergies";
	
	String historyOfCovid = "History of COVID";
	
	String symptomsStartedOn = "Symptoms started on";
	
	String fever = "Fever";
	
	String cough = "Cough";
	
	String shortnessOfBreath = "Shortness of breath";
	
	String lossOfSmellTaste = "Loss of smell/taste";
	
	String worsening = "Worsening";
	
	String improving = "Improving";
	
	String stable = "Stable";
	
	String ristFactors = "Risk Factors";
	
	String olderThan65 = "Older than 65?";
	
	String obese = "Obese (BMI > 30)";
	
	String diabetes = "Diabetes";
	
	String smokingHistory = "Smoking History";
	
	String lungDisease = "Lung Disease";
	
	String vitals = "Vitals";
	
	String height = "Height";
	
	String cm = "cm";
	
	String weight = "Weight";
	
	String kg = "kg,";
	
	String bloodPressure = "Blood Pressure";
	
	String mmHg = "mmHg,";
	
	String percentAt = "% at";
	
	String flowVia = "(flow) via";
	
	String device = "(device)";
	
	String labs = "Labs";
	
	String covidTest = "COVID Test: Positive or Negative (circle) via PCR or Rapid (circle).";
	
	String dateOfTest = "Date of test:";
	
	String bloodGlucoseLevel = "Blood Glucose Level:";
	
	String programDischargeNote = "Program Discharge Note";
	
	String phone = "Phone";
	
	String inPerson = "In Person";
	
	String pertinentEvents = "Pertinent Events";
	
	String completeTheFollowing = "If being safely discharged from the program please complete the following:";
	
	String postDischargePlan = "Post Discharge Plan";
	
	String primaryCareFollowUp = "Primary Care Follow Up:";
	
	String continueMeds = "Continue Medications";
	
	String discontinueMeds = "Discontinue Medications";
	
	String whenFollowUpWithPrimaryCare = "When to follow up with their primary care doctor?";
	
	String whichMedsToContinue = "Which medications they should continue?";
	
	String whichMedsToStop = "Which medications they should stop?";
	
	String whenMedEquipmentPickedUp = "When the medical equipment will be picked up?";
	
	String whoToContactForNonEmergency = "Who to contact from the program if they need non-emergency help?";
	
	String pleaseContactProgCoordinator = "Please contact program coordinator to update on discharge and any additional steps to be taken.";
	
	String selectSteroid = "Select Steroid";
	
	String selectAntibiotic = "Select Antibiotic";
	
	String selectAnticoagulation = "Select Anticoagulation";
	
	String selectDrug = "Select Drug";
	
	public String getSelectDrug() {
		return selectDrug;
	}
	
	public void setSelectDrug(String selectDrug) {
		this.selectDrug = selectDrug;
	}
	
	public String getCovidAtHome() {
		return covidAtHome;
	}
	
	public void setCovidAtHome(String covidAtHome) {
		this.covidAtHome = covidAtHome;
	}
	
	public String getPatientScreening() {
		return patientScreening;
	}
	
	public void setPatientScreening(String patientScreening) {
		this.patientScreening = patientScreening;
	}
	
	public String getFormDate() {
		return formDate;
	}
	
	public void setFormDate(String formDate) {
		this.formDate = formDate;
	}
	
	public String getCompletedBy() {
		return completedBy;
	}
	
	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}
	
	public String getRole() {
		return role;
	}
	
	public void setRole(String role) {
		this.role = role;
	}
	
	public String getPhysician() {
		return physician;
	}
	
	public void setPhysician(String physician) {
		this.physician = physician;
	}
	
	public String getNurse() {
		return nurse;
	}
	
	public void setNurse(String nurse) {
		this.nurse = nurse;
	}
	
	public String getOther() {
		return other;
	}
	
	public void setOther(String other) {
		this.other = other;
	}
	
	public String getInstructions() {
		return instructions;
	}
	
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
	
	public String getInstructions1() {
		return instructions1;
	}
	
	public void setInstructions1(String instructions1) {
		this.instructions1 = instructions1;
	}
	
	public String getInstructions2() {
		return instructions2;
	}
	
	public void setInstructions2(String instructions2) {
		this.instructions2 = instructions2;
	}
	
	public String getInstructions3() {
		return instructions3;
	}
	
	public void setInstructions3(String instructions3) {
		this.instructions3 = instructions3;
	}
	
	public String getConsent() {
		return consent;
	}
	
	public void setConsent(String consent) {
		this.consent = consent;
	}
	
	public String getConsentPhrase() {
		return consentPhrase;
	}
	
	public void setConsentPhrase(String consentPhrase) {
		this.consentPhrase = consentPhrase;
	}
	
	public String getYes() {
		return yes;
	}
	
	public void setYes(String yes) {
		this.yes = yes;
	}
	
	public String getNo() {
		return no;
	}
	
	public void setNo(String no) {
		this.no = no;
	}
	
	public String getIdentifiers() {
		return identifiers;
	}
	
	public void setIdentifiers(String identifiers) {
		this.identifiers = identifiers;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getMale() {
		return male;
	}
	
	public void setMale(String male) {
		this.male = male;
	}
	
	public String getFemale() {
		return female;
	}
	
	public void setFemale(String female) {
		this.female = female;
	}
	
	public String getBirthCertificate() {
		return birthCertificate;
	}
	
	public void setBirthCertificate(String birthCertificate) {
		this.birthCertificate = birthCertificate;
	}
	
	public String getPassport() {
		return passport;
	}
	
	public void setPassport(String passport) {
		this.passport = passport;
	}
	
	public String getIdNumber() {
		return idNumber;
	}
	
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	
	public String getScreening() {
		return screening;
	}
	
	public void setScreening(String screening) {
		this.screening = screening;
	}
	
	public String getInclusionCriteria() {
		return inclusionCriteria;
	}
	
	public void setInclusionCriteria(String inclusionCriteria) {
		this.inclusionCriteria = inclusionCriteria;
	}
	
	public String getInclusionCriteria1() {
		return inclusionCriteria1;
	}
	
	public void setInclusionCriteria1(String inclusionCriteria1) {
		this.inclusionCriteria1 = inclusionCriteria1;
	}
	
	public String getInclusionCriteria2() {
		return inclusionCriteria2;
	}
	
	public void setInclusionCriteria2(String inclusionCriteria2) {
		this.inclusionCriteria2 = inclusionCriteria2;
	}
	
	public String getInclusionCriteria3() {
		return inclusionCriteria3;
	}
	
	public void setInclusionCriteria3(String inclusionCriteria3) {
		this.inclusionCriteria3 = inclusionCriteria3;
	}
	
	public String getInclusionCriteria4() {
		return inclusionCriteria4;
	}
	
	public void setInclusionCriteria4(String inclusionCriteria4) {
		this.inclusionCriteria4 = inclusionCriteria4;
	}
	
	public String getInclusionCriteria5() {
		return inclusionCriteria5;
	}
	
	public void setInclusionCriteria5(String inclusionCriteria5) {
		this.inclusionCriteria5 = inclusionCriteria5;
	}
	
	public String getExclusionCriteria() {
		return exclusionCriteria;
	}
	
	public void setExclusionCriteria(String exclusionCriteria) {
		this.exclusionCriteria = exclusionCriteria;
	}
	
	public String getExclusionCriteria6() {
		return exclusionCriteria6;
	}
	
	public void setExclusionCriteria6(String exclusionCriteria6) {
		this.exclusionCriteria6 = exclusionCriteria6;
	}
	
	public String getExclusionCriteria7() {
		return exclusionCriteria7;
	}
	
	public void setExclusionCriteria7(String exclusionCriteria7) {
		this.exclusionCriteria7 = exclusionCriteria7;
	}
	
	public String getExclusionCriteria8() {
		return exclusionCriteria8;
	}
	
	public void setExclusionCriteria8(String exclusionCriteria8) {
		this.exclusionCriteria8 = exclusionCriteria8;
	}
	
	public String getExclusionCriteria9() {
		return exclusionCriteria9;
	}
	
	public void setExclusionCriteria9(String exclusionCriteria9) {
		this.exclusionCriteria9 = exclusionCriteria9;
	}
	
	public String getScreeningNote() {
		return screeningNote;
	}
	
	public void setScreeningNote(String screeningNote) {
		this.screeningNote = screeningNote;
	}
	
	public String getIsPatientEligible() {
		return isPatientEligible;
	}
	
	public void setIsPatientEligible(String isPatientEligible) {
		this.isPatientEligible = isPatientEligible;
	}
	
	public String getDailyHomeHealthNote() {
		return dailyHomeHealthNote;
	}
	
	public void setDailyHomeHealthNote(String dailyHomeHealthNote) {
		this.dailyHomeHealthNote = dailyHomeHealthNote;
	}
	
	public String getProviderRecordedVitals() {
		return providerRecordedVitals;
	}
	
	public void setProviderRecordedVitals(String providerRecordedVitals) {
		this.providerRecordedVitals = providerRecordedVitals;
	}
	
	public String getOverniteHistory() {
		return overniteHistory;
	}
	
	public void setOverniteHistory(String overniteHistory) {
		this.overniteHistory = overniteHistory;
	}
	
	public String getEquipmentIssues() {
		return equipmentIssues;
	}
	
	public void setEquipmentIssues(String equipmentIssues) {
		this.equipmentIssues = equipmentIssues;
	}
	
	public String getPatientProvidedDate() {
		return patientProvidedDate;
	}
	
	public void setPatientProvidedDate(String patientProvidedDate) {
		this.patientProvidedDate = patientProvidedDate;
	}
	
	public String getTime() {
		return time;
	}
	
	public void setTime(String time) {
		this.time = time;
	}
	
	public String getOxygenSaturation() {
		return oxygenSaturation;
	}
	
	public void setOxygenSaturation(String oxygenSaturation) {
		this.oxygenSaturation = oxygenSaturation;
	}
	
	public String getRespiratoryRate() {
		return respiratoryRate;
	}
	
	public void setRespiratoryRate(String respiratoryRate) {
		this.respiratoryRate = respiratoryRate;
	}
	
	public String getHeartRate() {
		return heartRate;
	}
	
	public void setHeartRate(String heartRate) {
		this.heartRate = heartRate;
	}
	
	public String getBloodGlucose() {
		return bloodGlucose;
	}
	
	public void setBloodGlucose(String bloodGlucose) {
		this.bloodGlucose = bloodGlucose;
	}
	
	public String getPlanForPatient() {
		return planForPatient;
	}
	
	public void setPlanForPatient(String planForPatient) {
		this.planForPatient = planForPatient;
	}
	
	public String getStayInProgram() {
		return stayInProgram;
	}
	
	public void setStayInProgram(String stayInProgram) {
		this.stayInProgram = stayInProgram;
	}
	
	public String getReturnToHospital() {
		return returnToHospital;
	}
	
	public void setReturnToHospital(String returnToHospital) {
		this.returnToHospital = returnToHospital;
	}
	
	public String getSafeToDischarge() {
		return safeToDischarge;
	}
	
	public void setSafeToDischarge(String safeToDischarge) {
		this.safeToDischarge = safeToDischarge;
	}
	
	public String getFollowUpOn() {
		return followUpOn;
	}
	
	public void setFollowUpOn(String followUpOn) {
		this.followUpOn = followUpOn;
	}
	
	public String getFinalNoteForm() {
		return finalNoteForm;
	}
	
	public void setFinalNoteForm(String finalNoteForm) {
		this.finalNoteForm = finalNoteForm;
	}
	
	public String getPlan() {
		return plan;
	}
	
	public void setPlan(String plan) {
		this.plan = plan;
	}
	
	public String getContinueTheFollowingMeds() {
		return continueTheFollowingMeds;
	}
	
	public void setContinueTheFollowingMeds(String continueTheFollowingMeds) {
		this.continueTheFollowingMeds = continueTheFollowingMeds;
	}
	
	public String getIfYesProvideMedInfo() {
		return ifYesProvideMedInfo;
	}
	
	public void setIfYesProvideMedInfo(String ifYesProvideMedInfo) {
		this.ifYesProvideMedInfo = ifYesProvideMedInfo;
	}
	
	public String getSteroids() {
		return steroids;
	}
	
	public void setSteroids(String steroids) {
		this.steroids = steroids;
	}
	
	public String getAntibiotics() {
		return antibiotics;
	}
	
	public void setAntibiotics(String antibiotics) {
		this.antibiotics = antibiotics;
	}
	
	public String getAnticoagulation() {
		return anticoagulation;
	}
	
	public void setAnticoagulation(String anticoagulation) {
		this.anticoagulation = anticoagulation;
	}
	
	public String getAntihyperglycemics() {
		return antihyperglycemics;
	}
	
	public void setAntihyperglycemics(String antihyperglycemics) {
		this.antihyperglycemics = antihyperglycemics;
	}
	
	public String getStartFollowingMeds() {
		return startFollowingMeds;
	}
	
	public void setStartFollowingMeds(String startFollowingMeds) {
		this.startFollowingMeds = startFollowingMeds;
	}
	
	public String getDexamethasone() {
		return dexamethasone;
	}
	
	public void setDexamethasone(String dexamethasone) {
		this.dexamethasone = dexamethasone;
	}
	
	public String getIfYesForAntibioticsProvideMedInfo() {
		return ifYesForAntibioticsProvideMedInfo;
	}
	
	public void setIfYesForAntibioticsProvideMedInfo(String ifYesForAntibioticsProvideMedInfo) {
		this.ifYesForAntibioticsProvideMedInfo = ifYesForAntibioticsProvideMedInfo;
	}
	
	public String getMonitorForGlucose() {
		return monitorForGlucose;
	}
	
	public void setMonitorForGlucose(String monitorForGlucose) {
		this.monitorForGlucose = monitorForGlucose;
	}
	
	public String getForProgramUseOnly() {
		return forProgramUseOnly;
	}
	
	public void setForProgramUseOnly(String forProgramUseOnly) {
		this.forProgramUseOnly = forProgramUseOnly;
	}
	
	public String getOxygen() {
		return oxygen;
	}
	
	public void setOxygen(String oxygen) {
		this.oxygen = oxygen;
	}
	
	public String getConcentratorId() {
		return concentratorId;
	}
	
	public void setConcentratorId(String concentratorId) {
		this.concentratorId = concentratorId;
	}
	
	public String getPulseOxId() {
		return pulseOxId;
	}
	
	public void setPulseOxId(String pulseOxId) {
		this.pulseOxId = pulseOxId;
	}
	
	public String getInitConcentratorSettings() {
		return initConcentratorSettings;
	}
	
	public void setInitConcentratorSettings(String initConcentratorSettings) {
		this.initConcentratorSettings = initConcentratorSettings;
	}
	
	public String getGlucoseMonitoring() {
		return glucoseMonitoring;
	}
	
	public void setGlucoseMonitoring(String glucoseMonitoring) {
		this.glucoseMonitoring = glucoseMonitoring;
	}
	
	public String getRequireAtHomeGlucoseMonitoring() {
		return requireAtHomeGlucoseMonitoring;
	}
	
	public void setRequireAtHomeGlucoseMonitoring(String requireAtHomeGlucoseMonitoring) {
		this.requireAtHomeGlucoseMonitoring = requireAtHomeGlucoseMonitoring;
	}
	
	public String getIfYesGlucoseId() {
		return ifYesGlucoseId;
	}
	
	public void setIfYesGlucoseId(String ifYesGlucoseId) {
		this.ifYesGlucoseId = ifYesGlucoseId;
	}
	
	public String getHomeInspection() {
		return homeInspection;
	}
	
	public void setHomeInspection(String homeInspection) {
		this.homeInspection = homeInspection;
	}
	
	public String getDoesPatientHaveFollowing() {
		return doesPatientHaveFollowing;
	}
	
	public void setDoesPatientHaveFollowing(String doesPatientHaveFollowing) {
		this.doesPatientHaveFollowing = doesPatientHaveFollowing;
	}
	
	public String getElectricity() {
		return electricity;
	}
	
	public void setElectricity(String electricity) {
		this.electricity = electricity;
	}
	
	public String getPhoneInternet() {
		return phoneInternet;
	}
	
	public void setPhoneInternet(String phoneInternet) {
		this.phoneInternet = phoneInternet;
	}
	
	public String getSafeHomeEnvirons() {
		return safeHomeEnvirons;
	}
	
	public void setSafeHomeEnvirons(String safeHomeEnvirons) {
		this.safeHomeEnvirons = safeHomeEnvirons;
	}
	
	public String getIfNoPatientShouldNotBeEnrolled() {
		return ifNoPatientShouldNotBeEnrolled;
	}
	
	public void setIfNoPatientShouldNotBeEnrolled(String ifNoPatientShouldNotBeEnrolled) {
		this.ifNoPatientShouldNotBeEnrolled = ifNoPatientShouldNotBeEnrolled;
	}
	
	public String getHasPatientBeenEducatedOnFollowing() {
		return hasPatientBeenEducatedOnFollowing;
	}
	
	public void setHasPatientBeenEducatedOnFollowing(String hasPatientBeenEducatedOnFollowing) {
		this.hasPatientBeenEducatedOnFollowing = hasPatientBeenEducatedOnFollowing;
	}
	
	public String getWhenToSeekMedHelp() {
		return whenToSeekMedHelp;
	}
	
	public void setWhenToSeekMedHelp(String whenToSeekMedHelp) {
		this.whenToSeekMedHelp = whenToSeekMedHelp;
	}
	
	public String getWhoToContactInEmergency() {
		return whoToContactInEmergency;
	}
	
	public void setWhoToContactInEmergency(String whoToContactInEmergency) {
		this.whoToContactInEmergency = whoToContactInEmergency;
	}
	
	public String getHowToUseConcentrator() {
		return howToUseConcentrator;
	}
	
	public void setHowToUseConcentrator(String howToUseConcentrator) {
		this.howToUseConcentrator = howToUseConcentrator;
	}
	
	public String getHowToCheckGlucose() {
		return howToCheckGlucose;
	}
	
	public void setHowToCheckGlucose(String howToCheckGlucose) {
		this.howToCheckGlucose = howToCheckGlucose;
	}
	
	public String getHowToCheckO2Saturation() {
		return howToCheckO2Saturation;
	}
	
	public void setHowToCheckO2Saturation(String howToCheckO2Saturation) {
		this.howToCheckO2Saturation = howToCheckO2Saturation;
	}
	
	public String getHowToUseLogBook() {
		return howToUseLogBook;
	}
	
	public void setHowToUseLogBook(String howToUseLogBook) {
		this.howToUseLogBook = howToUseLogBook;
	}
	
	public String getSmokingDangerWithO2() {
		return smokingDangerWithO2;
	}
	
	public void setSmokingDangerWithO2(String smokingDangerWithO2) {
		this.smokingDangerWithO2 = smokingDangerWithO2;
	}
	
	public String getWhoToContactFromProgram() {
		return whoToContactFromProgram;
	}
	
	public void setWhoToContactFromProgram(String whoToContactFromProgram) {
		this.whoToContactFromProgram = whoToContactFromProgram;
	}
	
	public String getPatientContactInfo() {
		return patientContactInfo;
	}
	
	public void setPatientContactInfo(String patientContactInfo) {
		this.patientContactInfo = patientContactInfo;
	}
	
	public String getPatientAddress() {
		return patientAddress;
	}
	
	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}
	
	public String getPatientPhoneNumber() {
		return patientPhoneNumber;
	}
	
	public void setPatientPhoneNumber(String patientPhoneNumber) {
		this.patientPhoneNumber = patientPhoneNumber;
	}
	
	public String getEmergencyContacts() {
		return emergencyContacts;
	}
	
	public void setEmergencyContacts(String emergencyContacts) {
		this.emergencyContacts = emergencyContacts;
	}
	
	public String getContactName() {
		return contactName;
	}
	
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	
	public String getEmergencyContactPhoneNumber() {
		return emergencyContactPhoneNumber;
	}
	
	public void setEmergencyContactPhoneNumber(String emergencyContactPhoneNumber) {
		this.emergencyContactPhoneNumber = emergencyContactPhoneNumber;
	}
	
	public String getRelationshipToPatient() {
		return relationshipToPatient;
	}
	
	public void setRelationshipToPatient(String relationshipToPatient) {
		this.relationshipToPatient = relationshipToPatient;
	}
	
	public String getHospitalHistory() {
		return hospitalHistory;
	}
	
	public void setHospitalHistory(String hospitalHistory) {
		this.hospitalHistory = hospitalHistory;
	}
	
	public String getPastMedicalHistory() {
		return pastMedicalHistory;
	}
	
	public void setPastMedicalHistory(String pastMedicalHistory) {
		this.pastMedicalHistory = pastMedicalHistory;
	}
	
	public String getPastSurgicalHistory() {
		return pastSurgicalHistory;
	}
	
	public void setPastSurgicalHistory(String pastSurgicalHistory) {
		this.pastSurgicalHistory = pastSurgicalHistory;
	}
	
	public String getCurrentTreatment() {
		return currentTreatment;
	}
	
	public void setCurrentTreatment(String currentTreatment) {
		this.currentTreatment = currentTreatment;
	}
	
	public String getDose() {
		return dose;
	}
	
	public void setDose(String dose) {
		this.dose = dose;
	}
	
	public String getFrequency() {
		return frequency;
	}
	
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	
	public String getLength() {
		return length;
	}
	
	public void setLength(String length) {
		this.length = length;
	}
	
	public String getStartedOn() {
		return startedOn;
	}
	
	public void setStartedOn(String startedOn) {
		this.startedOn = startedOn;
	}
	
	public String getAntibiotic1() {
		return antibiotic1;
	}
	
	public void setAntibiotic1(String antibiotic1) {
		this.antibiotic1 = antibiotic1;
	}
	
	public String getAntibiotic2() {
		return antibiotic2;
	}
	
	public void setAntibiotic2(String antibiotic2) {
		this.antibiotic2 = antibiotic2;
	}
	
	public String getOtherTreatments() {
		return otherTreatments;
	}
	
	public void setOtherTreatments(String otherTreatments) {
		this.otherTreatments = otherTreatments;
	}
	
	public String getAllergies() {
		return allergies;
	}
	
	public void setAllergies(String allergies) {
		this.allergies = allergies;
	}
	
	public String getHistoryOfCovid() {
		return historyOfCovid;
	}
	
	public void setHistoryOfCovid(String historyOfCovid) {
		this.historyOfCovid = historyOfCovid;
	}
	
	public String getSymptomsStartedOn() {
		return symptomsStartedOn;
	}
	
	public void setSymptomsStartedOn(String symptomsStartedOn) {
		this.symptomsStartedOn = symptomsStartedOn;
	}
	
	public String getFever() {
		return fever;
	}
	
	public void setFever(String fever) {
		this.fever = fever;
	}
	
	public String getCough() {
		return cough;
	}
	
	public void setCough(String cough) {
		this.cough = cough;
	}
	
	public String getShortnessOfBreath() {
		return shortnessOfBreath;
	}
	
	public void setShortnessOfBreath(String shortnessOfBreath) {
		this.shortnessOfBreath = shortnessOfBreath;
	}
	
	public String getLossOfSmellTaste() {
		return lossOfSmellTaste;
	}
	
	public void setLossOfSmellTaste(String lossOfSmellTaste) {
		this.lossOfSmellTaste = lossOfSmellTaste;
	}
	
	public String getWorsening() {
		return worsening;
	}
	
	public void setWorsening(String worsening) {
		this.worsening = worsening;
	}
	
	public String getImproving() {
		return improving;
	}
	
	public void setImproving(String improving) {
		this.improving = improving;
	}
	
	public String getStable() {
		return stable;
	}
	
	public void setStable(String stable) {
		this.stable = stable;
	}
	
	public String getRistFactors() {
		return ristFactors;
	}
	
	public void setRistFactors(String ristFactors) {
		this.ristFactors = ristFactors;
	}
	
	public String getOlderThan65() {
		return olderThan65;
	}
	
	public void setOlderThan65(String olderThan65) {
		this.olderThan65 = olderThan65;
	}
	
	public String getObese() {
		return obese;
	}
	
	public void setObese(String obese) {
		this.obese = obese;
	}
	
	public String getDiabetes() {
		return diabetes;
	}
	
	public void setDiabetes(String diabetes) {
		this.diabetes = diabetes;
	}
	
	public String getSmokingHistory() {
		return smokingHistory;
	}
	
	public void setSmokingHistory(String smokingHistory) {
		this.smokingHistory = smokingHistory;
	}
	
	public String getLungDisease() {
		return lungDisease;
	}
	
	public void setLungDisease(String lungDisease) {
		this.lungDisease = lungDisease;
	}
	
	public String getVitals() {
		return vitals;
	}
	
	public void setVitals(String vitals) {
		this.vitals = vitals;
	}
	
	public String getHeight() {
		return height;
	}
	
	public void setHeight(String height) {
		this.height = height;
	}
	
	public String getCm() {
		return cm;
	}
	
	public void setCm(String cm) {
		this.cm = cm;
	}
	
	public String getWeight() {
		return weight;
	}
	
	public void setWeight(String weight) {
		this.weight = weight;
	}
	
	public String getKg() {
		return kg;
	}
	
	public void setKg(String kg) {
		this.kg = kg;
	}
	
	public String getBloodPressure() {
		return bloodPressure;
	}
	
	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}
	
	public String getMmHg() {
		return mmHg;
	}
	
	public void setMmHg(String mmHg) {
		this.mmHg = mmHg;
	}
	
	public String getPercentAt() {
		return percentAt;
	}
	
	public void setPercentAt(String percentAt) {
		this.percentAt = percentAt;
	}
	
	public String getFlowVia() {
		return flowVia;
	}
	
	public void setFlowVia(String flowVia) {
		this.flowVia = flowVia;
	}
	
	public String getDevice() {
		return device;
	}
	
	public void setDevice(String device) {
		this.device = device;
	}
	
	public String getLabs() {
		return labs;
	}
	
	public void setLabs(String labs) {
		this.labs = labs;
	}
	
	public String getCovidTest() {
		return covidTest;
	}
	
	public void setCovidTest(String covidTest) {
		this.covidTest = covidTest;
	}
	
	public String getDateOfTest() {
		return dateOfTest;
	}
	
	public void setDateOfTest(String dateOfTest) {
		this.dateOfTest = dateOfTest;
	}
	
	public String getBloodGlucoseLevel() {
		return bloodGlucoseLevel;
	}
	
	public void setBloodGlucoseLevel(String bloodGlucoseLevel) {
		this.bloodGlucoseLevel = bloodGlucoseLevel;
	}
	
	public String getProgramDischargeNote() {
		return programDischargeNote;
	}
	
	public void setProgramDischargeNote(String programDischargeNote) {
		this.programDischargeNote = programDischargeNote;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getInPerson() {
		return inPerson;
	}
	
	public void setInPerson(String inPerson) {
		this.inPerson = inPerson;
	}
	
	public String getPertinentEvents() {
		return pertinentEvents;
	}
	
	public void setPertinentEvents(String pertinentEvents) {
		this.pertinentEvents = pertinentEvents;
	}
	
	public String getCompleteTheFollowing() {
		return completeTheFollowing;
	}
	
	public void setCompleteTheFollowing(String completeTheFollowing) {
		this.completeTheFollowing = completeTheFollowing;
	}
	
	public String getPostDischargePlan() {
		return postDischargePlan;
	}
	
	public void setPostDischargePlan(String postDischargePlan) {
		this.postDischargePlan = postDischargePlan;
	}
	
	public String getPrimaryCareFollowUp() {
		return primaryCareFollowUp;
	}
	
	public void setPrimaryCareFollowUp(String primaryCareFollowUp) {
		this.primaryCareFollowUp = primaryCareFollowUp;
	}
	
	public String getContinueMeds() {
		return continueMeds;
	}
	
	public void setContinueMeds(String continueMeds) {
		this.continueMeds = continueMeds;
	}
	
	public String getDiscontinueMeds() {
		return discontinueMeds;
	}
	
	public void setDiscontinueMeds(String discontinueMeds) {
		this.discontinueMeds = discontinueMeds;
	}
	
	public String getWhenFollowUpWithPrimaryCare() {
		return whenFollowUpWithPrimaryCare;
	}
	
	public void setWhenFollowUpWithPrimaryCare(String whenFollowUpWithPrimaryCare) {
		this.whenFollowUpWithPrimaryCare = whenFollowUpWithPrimaryCare;
	}
	
	public String getWhichMedsToContinue() {
		return whichMedsToContinue;
	}
	
	public void setWhichMedsToContinue(String whichMedsToContinue) {
		this.whichMedsToContinue = whichMedsToContinue;
	}
	
	public String getWhichMedsToStop() {
		return whichMedsToStop;
	}
	
	public void setWhichMedsToStop(String whichMedsToStop) {
		this.whichMedsToStop = whichMedsToStop;
	}
	
	public String getWhenMedEquipmentPickedUp() {
		return whenMedEquipmentPickedUp;
	}
	
	public void setWhenMedEquipmentPickedUp(String whenMedEquipmentPickedUp) {
		this.whenMedEquipmentPickedUp = whenMedEquipmentPickedUp;
	}
	
	public String getWhoToContactForNonEmergency() {
		return whoToContactForNonEmergency;
	}
	
	public void setWhoToContactForNonEmergency(String whoToContactForNonEmergency) {
		this.whoToContactForNonEmergency = whoToContactForNonEmergency;
	}
	
	public String getPleaseContactProgCoordinator() {
		return pleaseContactProgCoordinator;
	}
	
	public void setPleaseContactProgCoordinator(String pleaseContactProgCoordinator) {
		this.pleaseContactProgCoordinator = pleaseContactProgCoordinator;
	}
	
	public String getSelectSteroid() {
		return selectSteroid;
	}
	
	public void setSelectSteroid(String selectSteroid) {
		this.selectSteroid = selectSteroid;
	}
	
	public String getSelectAntibiotic() {
		return selectAntibiotic;
	}
	
	public void setSelectAntibiotic(String selectAntibiotic) {
		this.selectAntibiotic = selectAntibiotic;
	}
	
	public String getSelectAnticoagulation() {
		return selectAnticoagulation;
	}
	
	public void setSelectAnticoagulation(String selectAnticoagulation) {
		this.selectAnticoagulation = selectAnticoagulation;
	}
	
}
