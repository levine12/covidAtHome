/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid.fragment.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import org.openmrs.Concept;
import org.openmrs.Encounter;
import org.openmrs.EncounterType;
import org.openmrs.Location;
import org.openmrs.Obs;
import org.openmrs.Patient;
import org.openmrs.Person;
import org.openmrs.PersonAttributeType;
import org.openmrs.User;
import org.openmrs.Visit;
import org.openmrs.VisitType;
import org.openmrs.api.context.Context;
import org.openmrs.module.covid.page.controller.RestPostGet;
import org.openmrs.ui.framework.fragment.FragmentModel;

/**
 * @author barrylevine
 */
public class CovidFormPatientScreeningFragFragmentController {
	
	RestPostGet restCall = new RestPostGet();
	
	String baseURL;
	
	String patientIdURL;
	
	//String restUserName = "restuser";
	String restUserName = "admin";
	
	//String restUserPassword = "$kl@*Akjkj3344";
	String restUserPassword = "Admin123";
	
	String yesConceptUUID = Context.getConceptService().getConceptByName("Yes").getUuid();
	
	String noConceptUUID = Context.getConceptService().getConceptByName("No").getUuid();
	
	public void controller(HttpServletRequest request, FragmentModel model) {
		/*
		all the phrases for the web page  should be included in the Translation classes below
		The following 2 statements are used to set the phrase either in Armenian or English
		 */
		if (Context.getLocale().getDisplayName().equals("Armenian")) {
			model.addAttribute("phrases", new TranslationArmenian());
		} else {
			model.addAttribute("phrases", new TranslationEnglish());
		}
		String jsonPatientInfo = "{ " + "\"patientName\":\"Barry3 Patient\"," + "\"birthDate\":\"2012-05-06\","
		        + "\"gender\":\"Male\"," + "\"idNumber\":\"123453\"," + "\"idType\":\"Birth Certificate\"" + "}";
		
		String url = request.getRequestURL().toString();
		String contextPath = request.getContextPath();
		int contextPathIndex = url.indexOf(contextPath);
		String baseUrl1 = url.substring(0, contextPathIndex) + contextPath;
		baseURL = baseUrl1 + "/ws/rest/v1/";
		patientIdURL = baseUrl1 + "/module/idgen/generateIdentifier.form?source=1" + "&username=" + restUserName
		        + "&password=" + restUserPassword;
		//String patientUUID = registerPatientFromJSON(request, jsonPatientInfo);
		String jsonObsInfo = "{ " + "\"Pregnancy, miscarriage\": \"Yes\"," + "\"Postpartum Hemorrhage\": \"No\", "
		        + "\"VILLAGE\": " + "{\"Epilepsy\": \"Yes\", \"Chills\": \"Yes\" }" + "}";
		String jsonVisitDate = "{\"visitDate\": \"2020-03-15\"}";
		//createObsForPatientScreeningForm(patientUUID, jsonVisitDate, jsonObsInfo);
		//checkJson(jsonObsInfo);
	}
	
	private String registerPatientFromJSON(HttpServletRequest request, String jsonPatientInfo) {
		JsonObject jsonObject = new JsonParser().parse(jsonPatientInfo).getAsJsonObject();
		String patientName = jsonObject.get("patientName").getAsString();
		String birthDate = jsonObject.get("birthDate").getAsString();
		String gender = jsonObject.get("gender").getAsString();
		String idNumber = jsonObject.get("idNumber").getAsString();
		String idType = jsonObject.get("idType").getAsString();
		String patientUUID = getPatientUUID(patientName, birthDate, gender, idNumber);
		if (patientUUID != null) {
			System.out.println("PATIENT ALREADY CREATED: " + patientUUID);
			return patientUUID;
		}
		patientUUID = createPatient(patientName, birthDate, gender, idNumber);
		return patientUUID;
	}
	
	private String getPatientId() {
		try {
			String jsonResponse = restCall.doGetRestCall(patientIdURL);
			String newId = "";
			
			JsonParser prsr = new JsonParser();
			JsonElement jsEl = prsr.parse(jsonResponse);
			System.out.println("IDENTIFIERS");
			JsonObject obj = jsEl.getAsJsonObject();
			JsonArray resultArray = obj.getAsJsonArray("identifiers");
			
			for (JsonElement resultElement : resultArray) {
				newId = resultElement.getAsString();
				System.out.println("IDENTIFIER: " + newId);
			}
			return newId;
			
		}
		catch (Exception ex) {
			System.out.println("\n\n\n****************** getPatientIdGET ISSUE: " + ex + "\n\n\n");
		}
		return "";
	}
	
	private String createPatient(String patientName, String birthDate, String gender, String idNumber) {
		String patientId = getPatientId();
		System.out.println("PATIENT ID: " + patientId);
		gender = gender.equals("Male") ? "M" : "F";
		Location location = Context.getLocationService().getLocation("Screening Clinic Location");
		
		String action = "{ " + "\"identifiers\": " + "[{ " + "\"identifier\":\"" + patientId + "\", "
		        + "\"identifierType\":\"05a29f94-c0ed-11e2-94be-8c13b969e334\", " + "\"location\":\"LOCATIONUUID\", "
		        + "\"preferred\": true }], " + "\"person\": { " + "\"gender\": \"GENDER\", "
		        + "\"birthdate\": \"BIRTHDATE\", " + "\"names\": [{" + "\"givenName\": \"FIRSTNAME\", "
		        + "\"familyName\": \"LASTNAME\"}] " + " }} ";
		
		action = action.replace("GENDER", gender);
		action = action.replace("LOCATIONUUID", location.getUuid());
		action = action.replace("BIRTHDATE", birthDate);
		action = action.replace("FIRSTNAME", patientName);
		action = action.replace("LASTNAME", "lastName");
		System.out.println("\n\n\npostCreatePatient action:\n" + action + "\n\n");
		
		String jsonResponse = restCall.doPostRestCall(baseURL + "patient", action);
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonResponse);
		JsonObject obj = jsEl.getAsJsonObject();
		String patientUUID = obj.get("uuid").getAsString();
		System.out.println("\n\nNEW PATIENT UUID: " + patientUUID + "\n");
		PersonAttributeType attributeType = Context.getPersonService().getPersonAttributeTypeByName("idNumber");
		String attributeTypeUUID = attributeType.getUuid();
		action = "{  \"attributeType\": \"ATTRIBUTETYPEUUID\",  \"value\": \"ATTRIBUTEVALUE\"}";
		action = action.replace("ATTRIBUTETYPEUUID", attributeTypeUUID);
		action = action.replace("ATTRIBUTEVALUE", idNumber);
		jsonResponse = restCall.doPostRestCall(baseURL + "person/" + patientUUID + "/attribute", action);
		return patientUUID;
		
	}
	
	private String getPatientUUID(String patientName, String birthDate, String gender, String idNumber) {
		// lets match on gender, birthdate and idNumber - check with James
		List<Patient> patients = Context.getPatientService().getAllPatients();
		for (Patient patient : patients) {
			try {
				if (patient.getAttribute("idNumber").getValue().equals(idNumber)) {
					return patient.getUuid();
				}
			}
			catch (Exception ex) {
				// get here if old patients don't have id
				continue;
			}
		}
		return null;
	}
	
	private Encounter createEncounter(String patientUUID, String locationUUID, String visitUUID, String visitStartDateTime) {
		Patient patient = Context.getPatientService().getPatientByUuid(patientUUID);
		Location location = Context.getLocationService().getLocationByUuid(locationUUID);
		EncounterType encType = Context.getEncounterService().getEncounterType("ScreeningEncounterType");
		Visit visit = Context.getVisitService().getVisitByUuid(visitUUID);
		User creator = Context.getAuthenticatedUser();
		//Date encounterDateTime = new Date();
		Date encounterDateTime = null;
		try {
			encounterDateTime = new SimpleDateFormat("yyyy-MM-dd").parse(visitStartDateTime);
		}
		catch (ParseException ex) {
			Logger.getLogger(CovidFormPatientScreeningFragFragmentController.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		Encounter enc = new Encounter();
		enc.setPatient(patient);
		enc.setLocation(location);
		enc.setCreator(creator);
		enc.setEncounterDatetime(encounterDateTime);
		enc.setEncounterType(encType);
		enc.setVisit(visit);
		enc = Context.getEncounterService().saveEncounter(enc);
		return enc;
	}
	
	private void createObsForPatientScreeningForm(String patientUUID, String jsonVisitDate, String jsonObsInfo) {
		// this is just a test to verify how to save coded concepts in visit
		JsonObject jsonObject = new JsonParser().parse(jsonVisitDate).getAsJsonObject();
		String visitStartDateTime = jsonObject.get("visitDate").getAsString();
		
		String visitTypeUUID = "", encounterTypeUUID = "", locationUUID = "";
		List<VisitType> visitTypes = Context.getVisitService().getAllVisitTypes();
		for (VisitType oldVisitType : visitTypes) {
			if (oldVisitType.getName().equals("ScreeningVisitType")) {
				visitTypeUUID = oldVisitType.getUuid();
				break;
			}
		}
		encounterTypeUUID = Context.getEncounterService().getEncounterType("ScreeningEncounterType").getUuid();
		Location location = Context.getLocationService().getLocation("Screening Clinic Location");
		locationUUID = location.getUuid();
		String visitStartAction = "{ \"patient\":\"PATIENTUUID\", \"visitType\":\"VISITTYPEUUID\", "
		        + "\"location\":\"LOCATIONUUID\", " + "\"startDatetime\": \"STARTDATETIME\" }";
		
		visitStartAction = visitStartAction.replace("PATIENTUUID", patientUUID);
		visitStartAction = visitStartAction.replace("VISITTYPEUUID", visitTypeUUID);
		visitStartAction = visitStartAction.replace("LOCATIONUUID", locationUUID);
		visitStartAction = visitStartAction.replace("STARTDATETIME", visitStartDateTime);
		
		String jsonResponse = restCall.doPostRestCall(baseURL + "visit", visitStartAction);
		JsonParser prsr = new JsonParser();
		JsonElement jsEl = prsr.parse(jsonResponse);
		String visitUUID = jsEl.getAsJsonObject().get("uuid").getAsString();
		
		Encounter encounter = createEncounter(patientUUID, locationUUID, visitUUID, visitStartDateTime);
		createAllObs(patientUUID, visitStartDateTime, encounter, location, jsonObsInfo);
		
		/*        
		        Concept concept = Context.getConceptService().getConceptByName("Behavior");
		        Concept conceptAnswer = Context.getConceptService().getConceptByName("MaladaptiveCoping");

		        String obsAction = "{ " + "\"person\": \"PATIENTUUID\", " + "\"obsDatetime\": \"DATE\", "
		                + "\"concept\": \"CONCEPTUUID\", " + "\"location\": \"LOCATIONUUID\", "
		                + "\"encounter\": \"ENCOUNTERUUID\", " + "\"value\": \"VALUE\"}";
		        obsAction = obsAction.replace("PATIENTUUID", patientUUID);
		        obsAction = obsAction.replace("DATE", visitStartDateTime);
		        obsAction = obsAction.replace("CONCEPTUUID", concept.getUuid());
		        obsAction = obsAction.replace("LOCATIONUUID", locationUUID);
		        obsAction = obsAction.replace("ENCOUNTERUUID", encounterUuid);
		        obsAction = obsAction.replace("VALUE", conceptAnswer.getUuid());
		        jsonResponse = restCall.doPostRestCall(baseURL + "obs", obsAction);
		        System.out.println("\n\n\n\n\n****************OBS RESPONSE:\n\n" + jsonResponse);

		        String visitStopURL = baseURL + "visit/" + visitUuid;
		        String visitStopAction = "{\"stopDatetime\": \"STOPDATETIME\" }";

		        LocalDate parsedDate = LocalDate.parse(visitStartDateTime); //Parse date from String
		        LocalDate addedDate = parsedDate.plusDays(1); //Add
		        String dayAfterVisitDateTime = addedDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		        visitStopAction = visitStopAction.replace("STOPDATETIME", dayAfterVisitDateTime);
		        jsonResponse = restCall.doPostRestCall(visitStopURL, visitStopAction);
		        System.out.println("\n\n\n\n\n****************VISIT STOP RESPONSE:\n\n" + jsonResponse);
		 */
	}
	
	private void createAllObs(String patientUUID, String visitStartDateTime, Encounter encounter, Location location,
	        String jsonObsInfo) {
		Person person = Context.getPatientService().getPatientByUuid(patientUUID).getPerson();
		User creator = Context.getAuthenticatedUser();
		Date obsDateTime = null;
		try {
			obsDateTime = new SimpleDateFormat("yyyy-MM-dd").parse(visitStartDateTime);
		}
		catch (ParseException ex) {
			Logger.getLogger(CovidFormPatientScreeningFragFragmentController.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		JsonObject jsonObject = new JsonParser().parse(jsonObsInfo).getAsJsonObject();
		createObs(person, creator, obsDateTime, encounter, location, jsonObject);
		
		/*
		Concept conceptQuestion = Context.getConceptService().getConceptByName("Epilepsy");
		Concept conceptCodedAnswer = Context.getConceptService().getConceptByName("No");
		Obs obs = new Obs();
		obs.setEncounter(encounter);
		obs.setPerson(person);
		obs.setObsDatetime(obsDateTime);
		obs.setLocation(location);
		obs.setCreator(creator);
		obs.setConcept(conceptQuestion);
		obs.setValueCoded(conceptCodedAnswer);
		obs = Context.getObsService().saveObs(obs, "string");
		 */
	}
	
	private List<Obs> createObs(Person person, User creator, Date obsDateTime, Encounter encounter, Location location,
	        JsonObject jsonObject) {
		ArrayList<Obs> allObs = new ArrayList<Obs>();
		Obs nextObs;
		
		Set<Map.Entry<String, JsonElement>> entries = jsonObject.entrySet();
		String value = " ";
		JsonObject jsonObjectInner;
		String obsConceptString = null;
		for (Map.Entry<String, JsonElement> entry : entries) {
			try {
				obsConceptString = entry.getKey();
				value = jsonObject.get(obsConceptString).getAsString();
				nextObs = createAnObs(person, creator, obsDateTime, encounter, location, obsConceptString, value);
				//allObs.add(nextObs);
				System.out.println(entry.getKey() + ": " + value);
			}
			catch (Exception ex) {
				// at this point we have an obsgroup
				allObs = new ArrayList<Obs>();
				System.out.println("\n\n\nobsConceptString: " + obsConceptString + "\n\n\n");
				jsonObjectInner = jsonObject.getAsJsonObject(obsConceptString);
				Set<Map.Entry<String, JsonElement>> entriesInner = jsonObjectInner.entrySet();
				for (Map.Entry<String, JsonElement> entryInner : entriesInner) {
					value = jsonObjectInner.get(entryInner.getKey()).getAsString();
					nextObs = createAnObs(person, creator, obsDateTime, encounter, location, entryInner.getKey(), value);
					allObs.add(nextObs);
					System.out.println(entryInner.getKey() + ": " + value);
				}
				Obs groupObs = createAnObs(person, creator, obsDateTime, encounter, location, obsConceptString,
				    "ObsGroupppp");
				
				for (Obs obsGroupMember : allObs) {
					groupObs.addGroupMember(obsGroupMember);
				}
				System.out.println("\n\n\nOBS GROUP\n\n\n");
				Set<Obs> obsSet = groupObs.getGroupMembers();
				for (Obs obs : obsSet) {
					System.out.println(obs.getConcept().getName());
				}
				
			}
			
		}
		return allObs;
	}
	
	private Obs createAnObs(Person person, User creator, Date obsDateTime, Encounter encounter, Location location,
	        String conceptQuestionString, String conceptAnswerString) {
		Obs obs = new Obs();
		Concept conceptQuestion = Context.getConceptService().getConceptByName(conceptQuestionString);
		obs.setConcept(conceptQuestion);
		Concept conceptCodedAnswer = null;
		
		if (conceptQuestion.getDatatype().getName().equals("Coded")) {
			conceptCodedAnswer = Context.getConceptService().getConceptByName(conceptAnswerString);
			obs.setValueCoded(conceptCodedAnswer);
		} else if (conceptQuestion.getDatatype().getName().equals("Numeric")) {
			obs.setValueNumeric(Double.valueOf(conceptAnswerString));
		} else if (conceptQuestion.getDatatype().getName().equals("Text")) {
			obs.setValueText(conceptAnswerString);
		} else if (conceptQuestion.getDatatype().getName().equals("Date")) {
			Date obsDateAnswer = null;
			try {
				obsDateAnswer = new SimpleDateFormat("yyyy-MM-dd").parse(conceptAnswerString);
			}
			catch (ParseException ex) {
				Logger.getLogger(CovidFormPatientScreeningFragFragmentController.class.getName())
				        .log(Level.SEVERE, null, ex);
			}
		}
		
		obs.setEncounter(encounter);
		obs.setPerson(person);
		obs.setObsDatetime(obsDateTime);
		obs.setLocation(location);
		obs.setCreator(creator);
		
		obs.setValueCoded(conceptCodedAnswer);
		obs = Context.getObsService().saveObs(obs, "string");
		return obs;
	}
	
	private void checkJson(String jsonObsInfo) {
		JsonObject jsonObject = new JsonParser().parse(jsonObsInfo).getAsJsonObject();
		String preg = jsonObject.get("Pregnancy, miscarriage").getAsString();
		String postPart = jsonObject.get("Postpartum Hemorrhage").getAsString();
		JsonObject jsonObjectInner = jsonObject.getAsJsonObject("Diagnosis or problem");
		String epil = jsonObjectInner.get("Epilepsy").getAsString();
		String chills = jsonObjectInner.get("Chills").getAsString();
		//System.out.println("Pregnancy, miscarriage: " + preg + " " + postPart
		//        + " epil: " + epil + " chills: " + chills);
		System.out.println("\n\n");
		Set<Map.Entry<String, JsonElement>> entries = jsonObject.entrySet();
		String value = " ";
		for (Map.Entry<String, JsonElement> entry : entries) {
			try {
				value = jsonObject.get(entry.getKey()).getAsString();
				System.out.println(entry.getKey() + ": " + value);
			}
			catch (Exception ex) {
				jsonObjectInner = jsonObject.getAsJsonObject(entry.getKey());
				Set<Map.Entry<String, JsonElement>> entriesInner = jsonObjectInner.entrySet();
				for (Map.Entry<String, JsonElement> entryInner : entriesInner) {
					value = jsonObjectInner.get(entryInner.getKey()).getAsString();
					System.out.println(entryInner.getKey() + ": " + value);
				}
			}
			
		}
	}
	
}
