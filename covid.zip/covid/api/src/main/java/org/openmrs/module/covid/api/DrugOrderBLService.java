package org.openmrs.module.covid.api;

import java.util.List;
import org.openmrs.annotation.Authorized;
import org.openmrs.api.APIException;
import org.openmrs.api.OpenmrsService;
import org.openmrs.module.covid.CovidConfig;
import org.openmrs.module.covid.DrugOrderBL;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface DrugOrderBLService extends OpenmrsService {
	
	@Authorized()
	@Transactional(readOnly = true)
	public List<DrugOrderBL> getAllDrugOrders();
	
	@Authorized()
	@Transactional(readOnly = true)
	public DrugOrderBL getDrugOrderById(int id);
	
	@Authorized()
	@Transactional(readOnly = true)
	public List<DrugOrderBL> getDrugOrdersByPatientId(int patientId) throws APIException;
	
	@Authorized()
	@Transactional(readOnly = true)
	public List<DrugOrderBL> getDrugOrdersByEncounterId(int encounterId) throws APIException;
	
	@Authorized(CovidConfig.MODULE_PRIVILEGE)
	@Transactional
	public DrugOrderBL saveDrugOrder(DrugOrderBL drugOrder) throws APIException;
}
