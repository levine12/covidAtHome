package org.openmrs.module.covid.api.db.hibernate;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.openmrs.api.APIException;
import org.openmrs.api.db.hibernate.DbSessionFactory;
import org.openmrs.module.covid.DrugOrderBL;
import org.openmrs.module.covid.api.db.DrugOrderBLDao;

/**
 * @author levine
 */
public class HibernateDrugOrderBLDAO implements DrugOrderBLDao {
	
	private DbSessionFactory sessionFactory;
	
	public void setSessionFactory(DbSessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public List<DrugOrderBL> getAllDrugOrders() {
		Criteria crit = sessionFactory.getCurrentSession().createCriteria(DrugOrderBL.class);
		return crit.list();
	}
	
	public DrugOrderBL getDrugOrderById(int id) {
		return (DrugOrderBL) sessionFactory.getCurrentSession().get(DrugOrderBL.class, id);
	}
	
	public List<DrugOrderBL> getDrugOrdersByPatientId(int patientId) throws APIException {
		Criteria crit = sessionFactory.getCurrentSession().createCriteria(DrugOrderBL.class);
		crit.add(Restrictions.eq("patientId", patientId));
		return crit.list();
	}
	
	public List<DrugOrderBL> getDrugOrdersByEncounterId(int encounterId) throws APIException {
		Criteria crit = sessionFactory.getCurrentSession().createCriteria(DrugOrderBL.class);
		crit.add(Restrictions.eq("encounterId", encounterId));
		return crit.list();
	}
	
	public DrugOrderBL saveDrugOrder(DrugOrderBL drugOrder) throws APIException {
		sessionFactory.getCurrentSession().saveOrUpdate(drugOrder);
		return drugOrder;
	}
	
}
