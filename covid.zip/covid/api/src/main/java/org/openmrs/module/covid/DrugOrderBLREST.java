/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.covid;

import java.util.Date;
import org.openmrs.BaseOpenmrsData;
import org.openmrs.Drug;

/**
 * @author barrylevine
 */
public class DrugOrderBLREST extends BaseOpenmrsData {
	
	// these fields are required for covid project
	
	String drugUUID;
	
	Double dose;
	
	String doseUnitsConceptUUID;
	
	String frequencyUUID;
	
	String durationUnitsConceptUUID;
	
	Double duration;
	
	String encounterUUID;
	
	String patientUUID;
	
	String userUUID;
	
	Date dateCreated;
	
	public Date getDateCreated() {
		return dateCreated;
	}
	
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
	public String getDrugUUID() {
		return drugUUID;
	}
	
	public void setDrugUUID(String drugUUID) {
		this.drugUUID = drugUUID;
	}
	
	public Double getDose() {
		return dose;
	}
	
	public void setDose(Double dose) {
		this.dose = dose;
	}
	
	public String getDoseUnitsConceptUUID() {
		return doseUnitsConceptUUID;
	}
	
	public void setDoseUnitsConceptUUID(String doseUnitsConceptUUID) {
		this.doseUnitsConceptUUID = doseUnitsConceptUUID;
	}
	
	public String getFrequencyUUID() {
		return frequencyUUID;
	}
	
	public void setFrequencyUUID(String frequencyUUID) {
		this.frequencyUUID = frequencyUUID;
	}
	
	public String getDurationUnitsConceptUUID() {
		return durationUnitsConceptUUID;
	}
	
	public void setDurationUnitsConceptUUID(String durationUnitsConceptUUID) {
		this.durationUnitsConceptUUID = durationUnitsConceptUUID;
	}
	
	public Double getDuration() {
		return duration;
	}
	
	public void setDuration(Double duration) {
		this.duration = duration;
	}
	
	public String getEncounterUUID() {
		return encounterUUID;
	}
	
	public void setEncounterUUID(String encounterUUID) {
		this.encounterUUID = encounterUUID;
	}
	
	public String getPatientUUID() {
		return patientUUID;
	}
	
	public void setPatientUUID(String patientUUID) {
		this.patientUUID = patientUUID;
	}
	
	public String getUserUUID() {
		return userUUID;
	}
	
	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}
	
	@Override
	public Integer getId() {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
	@Override
	public void setId(Integer intgr) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}
	
}
