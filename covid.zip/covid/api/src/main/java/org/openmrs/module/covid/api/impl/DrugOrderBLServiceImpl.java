/**
 * This Source Code Form is subject to the terms of the Mozilla Public License,
 * v. 2.0. If a copy of the MPL was not distributed with this file, You can
 * obtain one at http://mozilla.org/MPL/2.0/. OpenMRS is also distributed under
 * the terms of the Healthcare Disclaimer located at http://openmrs.org/license.
 *
 * Copyright (C) OpenMRS Inc. OpenMRS is a registered trademark and the OpenMRS
 * graphic logo is a trademark of OpenMRS Inc.
 */
package org.openmrs.module.covid.api.impl;

import java.util.List;
import org.openmrs.api.APIException;
import org.openmrs.api.UserService;
import org.openmrs.api.impl.BaseOpenmrsService;
import org.openmrs.module.covid.DrugOrderBL;
import org.openmrs.module.covid.api.DrugOrderBLService;
import org.openmrs.module.covid.api.db.DrugOrderBLDao;

public class DrugOrderBLServiceImpl extends BaseOpenmrsService implements DrugOrderBLService {
	
	DrugOrderBLDao dao;
	
	UserService userService;
	
	/**
	 * Injected in moduleApplicationContext.xml
	 */
	public void setDao(DrugOrderBLDao dao) {
		this.dao = dao;
	}
	
	@Override
	public DrugOrderBL getDrugOrderById(int id) throws APIException {
		return dao.getDrugOrderById(id);
	}
	
	@Override
	public List<DrugOrderBL> getAllDrugOrders() throws APIException {
		return dao.getAllDrugOrders();
	}
	
	@Override
	public List<DrugOrderBL> getDrugOrdersByPatientId(int patientId) throws APIException {
		return dao.getDrugOrdersByPatientId(patientId);
	}
	
	@Override
	public List<DrugOrderBL> getDrugOrdersByEncounterId(int encounterId) throws APIException {
		return dao.getDrugOrdersByEncounterId(encounterId);
	}
	
	@Override
	public DrugOrderBL saveDrugOrder(DrugOrderBL drugOrder) throws APIException {
		return dao.saveDrugOrder(drugOrder);
	}
}
