/**
 * This Source Code Form is subject to the terms of the Mozilla Public License,
 * v. 2.0. If a copy of the MPL was not distributed with this file, You can
 * obtain one at http://mozilla.org/MPL/2.0/. OpenMRS is also distributed under
 * the terms of the Healthcare Disclaimer located at http://openmrs.org/license.
 *
 * Copyright (C) OpenMRS Inc. OpenMRS is a registered trademark and the OpenMRS
 * graphic logo is a trademark of OpenMRS Inc.
 */
package org.openmrs.module.covid;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openmrs.Concept;
import org.openmrs.EncounterType;
import org.openmrs.Location;
import org.openmrs.Person;
import org.openmrs.PersonAttributeType;
import org.openmrs.PersonName;
import org.openmrs.Privilege;
import org.openmrs.Role;
import org.openmrs.User;
import org.openmrs.VisitType;
import org.openmrs.api.APIException;
import org.openmrs.api.context.Context;
import org.openmrs.module.BaseModuleActivator;

/**
 * This class contains the logic that is run every time this module is either started or shutdown
 */
public class CovidActivator extends BaseModuleActivator {
	
	private Log log = LogFactory.getLog(this.getClass());
	
	String restUserName = "restuser";
	
	String restUserPassword = "$kl@*Akjkj3344";
	
	String restUserRoleName = "restUserRole";
	
	String restUserGivenName = "restusergivennamee", restUserFamilyName = "restuserfamilynamee";
	
	/**
	 * @see #started()
	 */
	public void started() {
		log.info("Started Covid");
		createPersonAttributes();
		screeningVisitSetup();
		createRestUser();
	}
	
	/**
	 * @see #shutdown()
	 */
	public void shutdown() {
		log.info("Shutdown Covid");
	}
	
	private void createPersonAttributes() {
		PersonAttributeType attributeType;
		attributeType = Context.getPersonService().getPersonAttributeTypeByName("idNumber");
		if (attributeType != null) {
			System.out.println("id attribute already generated!!!");
			return;
		}
		attributeType = new PersonAttributeType();
		
		attributeType.setFormat("java.lang.String");
		attributeType.setName("idNumber");
		attributeType.setDescription("Birth Certificate, passport, other");
		attributeType = Context.getPersonService().savePersonAttributeType(attributeType);
	}
	
	private void screeningVisitSetup() throws APIException {
		if (!isVisitTypeAlreadySaved("ScreeningVisitType")) {
			VisitType visitType = new VisitType();
			visitType.setName("ScreeningVisitType");
			visitType.setDescription("covid visit screening");
			Context.getVisitService().saveVisitType(visitType);
		}
		if (!isEncounterTypeAlreadySaved("ScreeningEncounterType")) {
			EncounterType encounterType = new EncounterType();
			encounterType.setName("ScreeningEncounterType");
			encounterType.setDescription("covid exam encounter");
			Context.getEncounterService().saveEncounterType(encounterType);
		}
		if (!isLocationAlreadySaved("Screening Clinic Location")) {
			Location location = new Location();
			location.setName("Screening Clinic Location");
			location.setCreator(Context.getAuthenticatedUser());
			Context.getLocationService().saveLocation(location);
		}
	}
	
	boolean isVisitTypeAlreadySaved(String newVisitType) {
		List<VisitType> visitTypes = Context.getVisitService().getAllVisitTypes();
		for (VisitType oldVisitType : visitTypes) {
			if (oldVisitType.getName().equals(newVisitType)) {
				return true;
			}
		}
		return false;
	}
	
	boolean isEncounterTypeAlreadySaved(String newEncounterType) {
		List<EncounterType> encounterTypes = Context.getEncounterService().getAllEncounterTypes();
		for (EncounterType oldEncounterType : encounterTypes) {
			if (oldEncounterType.getName().equals(newEncounterType)) {
				return true;
			}
		}
		return false;
	}
	
	boolean isLocationAlreadySaved(String newLocation) {
		List<Location> oldLocations = Context.getLocationService().getAllLocations();
		for (Location oldLocation : oldLocations) {
			if (oldLocation.getName().equals(newLocation)) {
				return true;
			}
		}
		return false;
	}
	
	private void createRestUser() {
		if (isUserAlreadyCreated(restUserName)) {
			System.out.println("USER ALREADY CREATED: " + restUserName);
			return;
		}
		
		Role role = createRole();
		User user = new User();
		user.addRole(role);
		Person person = createPerson();
		System.out.println("\n\nNEW PERSON: " + person.getUuid());
		user.setPerson(person);
		user.setUsername(restUserName);
		user = Context.getUserService().createUser(user, restUserPassword);
		System.out.println("\n\nNEW USER: " + user.getUuid());
	}
	
	private boolean isUserAlreadyCreated(String newUserName) {
		List<User> allUsers = Context.getUserService().getAllUsers();
		for (User user : allUsers) {
			if (user.getUsername().equals(newUserName)) {
				return true;
			}
		}
		return false;
	}
	
	private Person createPerson() {
		Person newPerson = new Person();
		newPerson.setGender("M");
		PersonName name = new PersonName();
		name.setGivenName(restUserGivenName);
		name.setFamilyName(restUserFamilyName);
		newPerson.addName(name);
		newPerson = Context.getPersonService().savePerson(newPerson);
		return newPerson;
	}
	
	private Role createRole() {
		Role newRole;
		if ((newRole = getRole(restUserRoleName)) != null) {
			System.out.println("ROLE ALREADY CREATED: " + restUserRoleName);
			return newRole;
		}
		newRole = new Role();
		newRole.setRole(restUserRoleName);
		newRole.setDescription("ROLE USED FOR REST CALLS");
		newRole = Context.getUserService().saveRole(newRole);
		addRolePrivileges(newRole);
		
		ArrayList<Role> roleArray = new ArrayList<Role>();
		List<Role> allRoles = Context.getUserService().getAllRoles();
		for (Role role : allRoles) {
			if (role.getName().equals("Provider") || role.getName().equals("System Developer")) {
				roleArray.add(role);
				Set<Role> inheritedRoles = new HashSet<Role>(roleArray);
				newRole.setInheritedRoles(inheritedRoles);
			}
		}
		newRole = Context.getUserService().saveRole(newRole);
		System.out.println("ROLE CREATED: " + restUserRoleName);
		return newRole;
	}
	
	private void addRolePrivileges(Role role) {
		Privilege newPrivilege = getAddUserPrivilege("Add Users");
		savePrivilegeToRole(role, newPrivilege);
		
		newPrivilege = getAddUserPrivilege("Add Concept Proposals");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("Edit Concept Proposals");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("get concept attribute types");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("get concept classes");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("get concept datatypes");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("get concept proposals");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("get concepts");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("view concepts");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("get concept map types");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("get concept reference terms");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("manage concepts");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("view concept classes");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("view concept datatypes");
		savePrivilegeToRole(role, newPrivilege);
		newPrivilege = getAddUserPrivilege("view concept proposals");
		savePrivilegeToRole(role, newPrivilege);
		
	}
	
	private void savePrivilegeToRole(Role role, Privilege newPrivilege) throws APIException {
		role.addPrivilege(newPrivilege);
		role = Context.getUserService().saveRole(role);
		
	}
	
	private Role getRole(String newRoleName) {
		List<Role> allRoles = Context.getUserService().getAllRoles();
		for (Role role : allRoles) {
			if (role.getName().equals(newRoleName)) {
				return role;
			}
		}
		return null;
	}
	
	private Privilege getAddUserPrivilege(String privilegeName) {
		List<Privilege> allPrivileges;
		allPrivileges = Context.getUserService().getAllPrivileges();
		for (Privilege privilege : allPrivileges) {
			if (privilege.getName().equalsIgnoreCase(privilegeName)) {
				return privilege;
			}
		}
		return null;
	}
	
}
