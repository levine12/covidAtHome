package org.openmrs.module.covid;

import java.util.Date;
import org.openmrs.BaseOpenmrsData;

/*
Concept sets to use:
Drug Dispensing Units Concept: "Dispensing units" e.g. box, packet
Drug Dosing Units Concept: "Dosing unit" e.g. capsule, drop
Drug Routes Concept: "Routes of administration" e.g. oral
Duration Units Concept: "Duration units" e.g. seconds, minutes
 */
public class DrugOrderBL extends BaseOpenmrsData {
	
	int id;
	
	int drugId;
	
	double dose, length, numDaysRemaining, quantity;
	
	double duration;
	
	int durationUnitsConceptId;
	
	int routeConceptId;
	
	int quantityUnitsConceptId;
	
	int doseUnitsConceptId;
	
	int orderFrequencyId;
	
	int num_refills;
	
	int ordererUserId;
	
	int encounterId;
	
	int patientId;
	
	String comments;
	
	// comments are from covid form, options are: 
	// Discharge Plan - continue, Discharge Plan - start,
	// Hospital History - Current Treatment
	// Discharge Note - Continue, Discharge Note - Discontinue
	Date dateCreated, dateStarted;
	
	public int getDrugId() {
		return drugId;
	}
	
	public void setDrugId(int drugId) {
		this.drugId = drugId;
	}
	
	public double getDose() {
		return dose;
	}
	
	public void setDose(double dose) {
		this.dose = dose;
	}
	
	public double getLength() {
		return length;
	}
	
	public void setLength(double length) {
		this.length = length;
	}
	
	public double getNumDaysRemaining() {
		return numDaysRemaining;
	}
	
	public void setNumDaysRemaining(double numDaysRemaining) {
		this.numDaysRemaining = numDaysRemaining;
	}
	
	public double getQuantity() {
		return quantity;
	}
	
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	
	public double getDuration() {
		return duration;
	}
	
	public void setDuration(double duration) {
		this.duration = duration;
	}
	
	public int getDurationUnitsConceptId() {
		return durationUnitsConceptId;
	}
	
	public void setDurationUnitsConceptId(int durationUnitsConceptId) {
		this.durationUnitsConceptId = durationUnitsConceptId;
	}
	
	public int getRouteConceptId() {
		return routeConceptId;
	}
	
	public void setRouteConceptId(int routeConceptId) {
		this.routeConceptId = routeConceptId;
	}
	
	public int getQuantityUnitsConceptId() {
		return quantityUnitsConceptId;
	}
	
	public void setQuantityUnitsConceptId(int quantityUnitsConceptId) {
		this.quantityUnitsConceptId = quantityUnitsConceptId;
	}
	
	public int getDoseUnitsConceptId() {
		return doseUnitsConceptId;
	}
	
	public void setDoseUnitsConceptId(int doseUnitsConceptId) {
		this.doseUnitsConceptId = doseUnitsConceptId;
	}
	
	public int getOrderFrequencyId() {
		return orderFrequencyId;
	}
	
	public void setOrderFrequencyId(int orderFrequencyId) {
		this.orderFrequencyId = orderFrequencyId;
	}
	
	public int getNum_refills() {
		return num_refills;
	}
	
	public void setNum_refills(int num_refills) {
		this.num_refills = num_refills;
	}
	
	public int getOrdererUserId() {
		return ordererUserId;
	}
	
	public void setOrdererUserId(int ordererUserId) {
		this.ordererUserId = ordererUserId;
	}
	
	public int getEncounterId() {
		return encounterId;
	}
	
	public void setEncounterId(int encounterId) {
		this.encounterId = encounterId;
	}
	
	public int getPatientId() {
		return patientId;
	}
	
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public Date getDateCreated() {
		return dateCreated;
	}
	
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
	public Date getDateStarted() {
		return dateStarted;
	}
	
	public void setDateStarted(Date dateStarted) {
		this.dateStarted = dateStarted;
	}
	
	public Integer getId() {
		return id;
	}
	
	@Override
	public void setId(Integer id) {
		this.id = id;
	}
	
}
